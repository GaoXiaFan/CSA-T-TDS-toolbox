load('lambdarootf0_matrix.mat');
NUdelay0=0;
for k=1:1:length(lambdarootf0_matrix)
     if lambdarootf0_matrix(k) > 0
       NUdelay0=NUdelay0+1;
    end
end
fprintf('Results of complete stability analysis by CSA-T-TDS Toolbox:\n')
 if NUdelay0>0
       disp('The system doesn''t have a stable interval.');
       fprintf('For ''NU vs.tau'' plot, please see Figure ''NU Distribution''.\n')
       NUtauforUnstability(NUdelay0);
       return
   end
   if NUdelay0==0
       disp('The system is delay-independent stable.');
       return
   end