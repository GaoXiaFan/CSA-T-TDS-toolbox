function NUtau(CDsandPeriods)
global tau_max;
global numberofgridstoNUtau;
load('w_and_DeltaMatrix.mat');
load('lambdarootf0_matrix.mat');
 delta=w_and_DeltaMatrix(:,2);
 matrix_w = w_and_DeltaMatrix(:,1);
% load('matrix_wAndNumberOfCriticalPairs.mat');
% load('newMatrixfor_wandz.mat');
%  if ~isempty(newMatrixfor_wandz)
%  newMatrixfor_wandz = cell2mat(newMatrixfor_wandz);
% sumColumns= sum(newMatrixfor_wandz(:,2));
%  matrix_w=zeros(1,sumColumns);
%  m=1;
%  for k=1:1:size(newMatrixfor_wandz,1)
%      if newMatrixfor_wandz(k,2) == 1
%          matrix_w(1,m)=newMatrixfor_wandz(k,1);
%          m=m+1;
%      end
%      if newMatrixfor_wandz(k,2) ~= 1
%          matrix_w(1,m:m+newMatrixfor_wandz(k,2)-1)=newMatrixfor_wandz(k,1);
%          m=m+newMatrixfor_wandz(k,2);
%      end
%  end
%  end
matrix_wandCDsandPeriods=[matrix_w';CDsandPeriods];
for m=1:1:size(CDsandPeriods,2)
    if matrix_wandCDsandPeriods(2,m) == 0
       matrix_wandCDsandPeriods(2,m)=2*pi/matrix_wandCDsandPeriods(1,m);
    end
end
NUdelay0=0;
for k=1:1:length(lambdarootf0_matrix)
    if lambdarootf0_matrix(k) > 0
       NUdelay0=NUdelay0+1;
    end
end
NUtau_value=NUdelay0;
CDsandPeriods=matrix_wandCDsandPeriods(2:3,:);
tau=0:tau_max/numberofgridstoNUtau:tau_max;
    for k=1:1:length(delta)
        NUtau_value=NUtau_value+2*delta(k)*floor(((tau+CDsandPeriods(2,k)-CDsandPeriods(1,k))/CDsandPeriods(2,k)));
%     FinalNUtau=[FinalNUtau,NUtau_value];
    end

h=figure('NumberTitle','off','Name','NU Distribution');
plot(tau,NUtau_value)
xlabel('\tau')
ylabel('NU(\tau)')
AllCDsandDeltaintau_max=[];
for NumberofCD0=1:1:length(delta)
    CDs=CDsandPeriods(1,NumberofCD0);
    while (CDs<tau_max)
     AllCDsandDeltaintau_max=[AllCDsandDeltaintau_max,[CDs;delta(NumberofCD0)]];
     CDs=CDs+CDsandPeriods(2,NumberofCD0);
    end
end
CDsrow=AllCDsandDeltaintau_max(1,:);
Deltasrow=AllCDsandDeltaintau_max(2,:);
[CDsrow,order]=sort(CDsrow);
Deltasrow=Deltasrow(order);

 LeftMarginoftau=[];  
 RightMarginoftau=[];
 %NUdelay0=2;
 if NUdelay0==0
      LeftMarginoftau=[LeftMarginoftau,0]; 
 end
 NUdelay0(1)=NUdelay0;
 for k=1:1:length(CDsrow)
     NUdelay0(k+1)=NUdelay0(k)+2*Deltasrow(k);
%      if NUdelay0==0
%          LeftMarginoftau=[LeftMarginoftau,CDsrow(k)];
 end
for p=2:1:(k+1)
    if NUdelay0(p)==0&&NUdelay0(p-1)~=0
         LeftMarginoftau=[LeftMarginoftau,CDsrow(p-1)]; 
    end
    if NUdelay0(p)~=0&&NUdelay0(p-1)==0
        RightMarginoftau=[RightMarginoftau,CDsrow(p-1)];
    end
end
if length(LeftMarginoftau) > length(RightMarginoftau)
    RightMarginoftau=[RightMarginoftau,tau_max];
end

NumberofStabilityIntervals=length(RightMarginoftau);
 fprintf('Results of complete stability analysis by CSA-T-TDS Toolbox:\n')
 fprintf('\t\t The number of stability delay-intervals is %d.\n',NumberofStabilityIntervals)
 if NumberofStabilityIntervals~=0
     
     fprintf('\t\t The stability delay-interval(s) is(are):\n');
    if LeftMarginoftau(1)==0
        fprintf('\t\t [0,%.4f)\n',RightMarginoftau(1));
       for KLeftMarginoftau1=2:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau1),RightMarginoftau(KLeftMarginoftau1));
       end
    else
        for KLeftMarginoftau2=1:1:length(LeftMarginoftau)
    %       for Kinterval=1:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau2),RightMarginoftau(KLeftMarginoftau2));
        end
    end 
 end
     fprintf('\t\t For ''NU vs.tau'' plot, please see Figure ''NU Distribution''.\n') 