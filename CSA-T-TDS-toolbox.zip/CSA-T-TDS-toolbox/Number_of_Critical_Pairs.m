function varargout = Number_of_Critical_Pairs(varargin)
% NUMBER_OF_CRITICAL_PAIRS MATLAB code for Number_of_Critical_Pairs.fig
%      NUMBER_OF_CRITICAL_PAIRS, by itself, creates a new NUMBER_OF_CRITICAL_PAIRS or raises the existing
%      singleton*.
%
%      H = NUMBER_OF_CRITICAL_PAIRS returns the handle to a new NUMBER_OF_CRITICAL_PAIRS or the handle to
%      the existing singleton*.
%
%      NUMBER_OF_CRITICAL_PAIRS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NUMBER_OF_CRITICAL_PAIRS.M with the given input arguments.
%
%      NUMBER_OF_CRITICAL_PAIRS('Property','Value',...) creates a new NUMBER_OF_CRITICAL_PAIRS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Number_of_Critical_Pairs_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Number_of_Critical_Pairs_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Number_of_Critical_Pairs

% Last Modified by GUIDE v2.5 01-Jun-2021 16:58:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Number_of_Critical_Pairs_OpeningFcn, ...
                   'gui_OutputFcn',  @Number_of_Critical_Pairs_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Number_of_Critical_Pairs is made visible.
function Number_of_Critical_Pairs_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Number_of_Critical_Pairs (see VARARGIN)

% Choose default command line output for Number_of_Critical_Pairs
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
%set(gcf,'NumberTitle', 'off','Name','Critical frenquencies');
global fzlambda;
global q;
load('matrix_number_of_critical_pairs.mat');

set(handles.wAndNumberOfCriticalPairs_gui,'Data',matrix_number_of_critical_pairs,'ColumnEditable',true); 
save('matrix_number_of_critical_pairs.mat','matrix_number_of_critical_pairs'); %�����������Ա��棬�����´�ʹ��
syms s;
% newMatrix=cell2mat(newMatrix);
for n=1:1:size(matrix_number_of_critical_pairs,1)
    omega_vector(n)=cell2mat(matrix_number_of_critical_pairs(n,1));
end
%     fzlambda=[s^4+2*s^2,3,-3,1]; 
%     omega_vector=[1.9566,1];
for k=1:1:length(omega_vector)
      curretomega=omega_vector(k) ;
      fzlambda_value(k,:)=subs(fzlambda,s,curretomega*j) ;
      z(k,:)=vpa(roots(fzlambda_value(k,:)));
          abs_z(k,:)=abs(z(k,:));
end
fprintf('All critical omega and the corresponding z and |z| are listed below:\n');
for m=1:1:length(omega_vector)
    fprintf('\t (%.16f)\n',omega_vector(m));
   for a=1:1:q
   fprintf('\t (%s)',z(m,a));
   end
    fprintf('\n');
    for b=1:1:q
    fprintf('\t (%.32f)',abs_z(m,b));
    end
    fprintf('\n');
end



% UIWAIT makes Number_of_Critical_Pairs wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Number_of_Critical_Pairs_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function wAndNumberOfCriticalPairs_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wAndNumberOfCriticalPairs_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when entered data in editable cell(s) in wAndNumberOfCriticalPairs_gui.
function wAndNumberOfCriticalPairs_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to wAndNumberOfCriticalPairs_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_wAndNumberOfCriticalPairs = get(hObject,'Data');
matrix_number_of_critical_pairs=matrix_wAndNumberOfCriticalPairs;
save('matrix_wAndNumberOfCriticalPairs.mat','matrix_wAndNumberOfCriticalPairs');
save('matrix_number_of_critical_pairs.mat','matrix_number_of_critical_pairs');


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)

% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%�ж�critical paris�Ƿ񶼵���1
flag=0;
matrix_wAndNumberOfCriticalPairs=get(handles.wAndNumberOfCriticalPairs_gui,'Data');
save('matrix_wAndNumberOfCriticalPairs.mat','matrix_wAndNumberOfCriticalPairs');
matrix_NumberOfCriticalPairs=matrix_wAndNumberOfCriticalPairs(:,2);
matrix_NumberOfCriticalPairs=cell2mat(matrix_NumberOfCriticalPairs);
for k=1:1:length(matrix_NumberOfCriticalPairs)
    if matrix_NumberOfCriticalPairs(k) ~= 1
        flag=flag+1;
        break;
    end
end
% if flag == 0
%     matrix_wAndNumberOfCriticalPairs=cell2mat(matrix_wAndNumberOfCriticalPairs);
%     matrix_w=matrix_wAndNumberOfCriticalPairs(:,1);
%     deltaNU=effectdeltaNUfor_g1;
%     matrix_wanddeltaNUforassociatedFSCs_g1=[matrix_w,deltaNU'] ;
%     save('matrix_wanddeltaNUforassociatedFSCs_g1.mat','matrix_wanddeltaNUforassociatedFSCs_g1');
%     close(Number_of_Critical_Pairs);
%     DeltaNUforassociated_FSCs_g1;
% %[CDsandPeriods]=CDsandPeriods(fzlambda)
% end
% if flag ~= 0
%     matrix_number_of_critical_pairs=matrix_wAndNumberOfCriticalPairs;
%     matrix_number_of_critical_pairs=cell2mat(matrix_number_of_critical_pairs);
%     sumColumns= sum(matrix_number_of_critical_pairs(:,2));
%     matrix_w=zeros(1,sumColumns);
%     m=1;
%      for k=1:1:size(matrix_number_of_critical_pairs,1)
%          if matrix_number_of_critical_pairs(k,2) == 1
%              matrix_w(1,m)=matrix_number_of_critical_pairs(k,1);
%              m=m+1;
%          end
%          if matrix_number_of_critical_pairs(k,2) ~= 1
%              matrix_w(1,m:m+matrix_number_of_critical_pairs(k,2)-1)=matrix_number_of_critical_pairs(k,1);
%              m=m+matrix_number_of_critical_pairs(k,2);
%          end
%      end    
%      matrix_1=zeros(1,sumColumns);
%      matrix_1(1,:)=1;
%     matrix_number_of_critical_pairs=[matrix_w',matrix_1'];
% end

%flag == 0��ʾcritical paris������1�����

    global fzlambda;
    syms s;
    load('matrix_number_of_associated_FSCs.mat');
    matrix_number_of_associated_FSCs=cell2mat(matrix_number_of_associated_FSCs);
    matrix_w_associatedFSCs_g1=[];%����ж���Ƶ��ɨ�����ߵ�w�ľ���
    matrix_w_associatedsingleFSC_g1=[];%��ŵ���Ƶ��ɨ�����ߵ�w�ľ���
    for indexw = 1:1:size(matrix_number_of_associated_FSCs,1)
        if matrix_number_of_associated_FSCs(indexw,2) == 1
           matrix_w_associatedsingleFSC_g1=[matrix_w_associatedsingleFSC_g1,matrix_number_of_associated_FSCs(indexw,1)] ;
        end
        if matrix_number_of_associated_FSCs(indexw,2) ~= 1
            numberofassociatedFSCs=matrix_number_of_associated_FSCs(indexw,2);
            for index_numberofassociatedFSCs =1 :1 : matrix_number_of_associated_FSCs(indexw,2)
                if  numberofassociatedFSCs ~= 0
                 matrix_w_associatedFSCs_g1=[matrix_w_associatedFSCs_g1,matrix_number_of_associated_FSCs(indexw,1)];
                 numberofassociatedFSCs=numberofassociatedFSCs-1;
                end
            end
        end
    end

    %����ж���Ƶ��ɨ�����ߵ�omega����z�Լ�z�ľ���ֵ
    zforassociatedFSCs_g1=[];
    for numw=1:1:length(matrix_w_associatedFSCs_g1)
          curretomegaforassociatedFSCs_g1=matrix_w_associatedFSCs_g1(numw); 
          fzlambda_valueforassociatedFSCs_g1(numw,:)=subs(fzlambda,s,curretomegaforassociatedFSCs_g1*j) ;
          zforassociatedFSCs_g1all=vpa(roots(fzlambda_valueforassociatedFSCs_g1(numw,:)));
          [zforassociatedFSCs_g1effectrow,zforassociatedFSCs_g1effectcol]=min(abs(abs(zforassociatedFSCs_g1all)-1));
              
          zforassociatedFSCs_g1=[zforassociatedFSCs_g1;zforassociatedFSCs_g1all(zforassociatedFSCs_g1effectcol)];
    end
          %abs_zforassociatedFSCs_g1(1,:)=abs(zforassociatedFSCs_g1(1,:));

     matrix_wandzforassociatedFSCs_g1=[double(matrix_w_associatedFSCs_g1'),double(zforassociatedFSCs_g1)];
     matrix_wandzforassociatedFSCs_g1=[matrix_wandzforassociatedFSCs_g1,zeros(size(matrix_wandzforassociatedFSCs_g1,1),1)];
     matrix_wandzforassociatedFSCs_g1=num2cell(matrix_wandzforassociatedFSCs_g1);

     %�������Ƶ��ɨ�����ߵ�omega����z�Լ�z�ľ���ֵ
     effectzforassociatedsingleFSC_g1=[];
     for k=1:1:length(matrix_w_associatedsingleFSC_g1)
          curretomegaforassociatedsingleFSC_g1=matrix_w_associatedsingleFSC_g1(k); 
          fzlambda_valueforassociatedsingleFSC_g1(k,:)=subs(fzlambda,s,curretomegaforassociatedsingleFSC_g1*j) ;
          zforassociatedsingleFSC_g1(k,:)=vpa(roots(fzlambda_valueforassociatedsingleFSC_g1(k,:)));
          abs_zforassociatedsingleFSC_g1(k,:)=abs(zforassociatedsingleFSC_g1(k,:));
          [sortabs_zforassociatedsingleFSC_g1(k,:),index(k,:)]=sort(abs((abs_zforassociatedsingleFSC_g1(k,:)-1)));
          
          effectzforassociatedsingleFSC_g1=[effectzforassociatedsingleFSC_g1;zforassociatedsingleFSC_g1(k,index(k,1))] ;
          %effectabs_zforassociatedsingleFSC_g1(k,:)=abs_zforassociatedsingleFSC_g1(k,index(k,1));
     end

     matrix_wandzforassociatedsingleFSC_g1=[double(matrix_w_associatedsingleFSC_g1'),double(effectzforassociatedsingleFSC_g1)];
     matrix_wandzforassociatedsingleFSC_g1=num2cell(matrix_wandzforassociatedsingleFSC_g1);
     save('matrix_wandzforassociatedsingleFSC_g1.mat','matrix_wandzforassociatedsingleFSC_g1');
     save('matrix_wandzforassociatedFSCs_g1.mat','matrix_wandzforassociatedFSCs_g1');
     save('matrix_w_associatedsingleFSC_g1.mat','matrix_w_associatedsingleFSC_g1');
     if flag == 0
     selectzforassociatedFSCs_g1;
     close(Number_of_Critical_Pairs)
     end
if flag ~= 0
    %����ж���Ƶ��ɨ�����߲���critical pairs����1��omega��z��g
    matrix_wandzandgforassociatedFSCs_multig=zeros(size(matrix_wandzforassociatedFSCs_g1,1),4);
    matrix_wandzandgforassociatedFSCs_multig(:,1:2)=cell2mat(matrix_wandzforassociatedFSCs_g1(:,1:2));
    matrix_wandzandgforassociatedFSCs_multig(:,3)=1;
    matrix_wandzandgforassociatedFSCs_multig(:,4)=0;
    matrix_wandzandgforassociatedFSCs_multig=num2cell(matrix_wandzandgforassociatedFSCs_multig);
    
    
    save('matrix_wandzandgforassociatedFSCs_multig.mat','matrix_wandzandgforassociatedFSCs_multig');
    selectzforassociatedFSCs_multig
    close(Number_of_Critical_Pairs)
end
     
    
% --- Executes on button press in return_gui.
function return_gui_Callback(hObject, eventdata, handles)
% hObject    handle to return_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Number_of_Critical_Pairs)
number_of_associated_FSCs
