function selectzforassociatedFSCs_g1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to selectzforassociatedFSCs_g1 (see VARARGIN)

% Choose default command line output for selectzforassociatedFSCs_g1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes selectzforassociatedFSCs_g1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);
global rowIndex;
rowIndex=[];
load('matrix_wandzandabsz.mat')
set(handles.selectzforassociatedFSCs_g1_gui,'Data',matrix_wandzandabsz,'ColumnEditable',true);

function selectzforassociatedFSCs_g1_gui_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to selectzforassociatedFSCs_g1_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
effectrowIndex=[];
hang = eventdata.Indices(:,1);%��ȡ������
if isempty(hang)  
     return
end
if eventdata.Indices(2)==3%���ѡ����ǵ�����checkbox������в���
%                 event.Source.Data(event.Indices(1),event.Indices(2))
%                 �������data�н���һ�У����ã����������data�Ǿ���������ʹ��{}
      if eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2) }                
         eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)}=false;
      else
          eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)} =true;
      end
end
matrix = get(hObject,'Data');        %��ȡ���ݾ���
 selectIndex={1};           %��������б�ѡ��Ϊ1���ǲ�Ҫ���������
    rowIndex =[rowIndex,hang];          %��������ֵ
   for m=1:1:length(rowIndex)
        if isequal(matrix(rowIndex(m),3),selectIndex)
            effectrowIndex =[effectrowIndex,rowIndex(m)];%��������ֵ
        end
  end
  effectrowIndex=sort(unique(effectrowIndex));
   rowIndex=effectrowIndex;
handles.effectrowIndex = effectrowIndex;             %�����������ӵ��ṹ��
 guidata(hObject, handles); 

 
 function merge_gui_Callback(hObject, eventdata, handles)
% hObject    handle to merge_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
rowIndex=[];
effectrowIndex = handles.effectrowIndex;
load('matrix_wandzandabsz.mat');
matrix_wandzandabsz = get(handles.selectzforassociatedFSCs_g1_gui,'Data');
matrix_wandzandabsz=matrix_wandzandabsz(:,1:3)    %��ȡ�������ݾ���
matrix_wandzandabsz=cell2mat(matrix_wandzandabsz)
mergeData = matrix_wandzandabsz(effectrowIndex,:)
%round(a*2)/2
matrix_wandzandabsz(effectrowIndex(1),:) = mean(mergeData)
for k=2:length(effectrowIndex)
    matrix_wandzandabsz(effectrowIndex(k),:) = [];
end
matrix_wandzandabsz=[matrix_wandzandabsz,zeros(size(matrix_wandzandabsz,1),1)];
matrix_wandzandabsz=num2cell(matrix_wandzandabsz)
set(handles.selectzforassociatedFSCs_g1_gui,'Data',matrix_wandzandabsz); 
 save('matrix_wandzandabsz.mat','matrix_wandzandabsz');  %����һ������
 
 function selectzforassociatedFSCs_g1_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to selectzforassociatedFSCs_g1_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_wandzandabsz = get(hObject,'Data');
save('matrix_wandzandabsz.mat','matrix_wandzandabsz');


selectzforassociatedFSCs_g1