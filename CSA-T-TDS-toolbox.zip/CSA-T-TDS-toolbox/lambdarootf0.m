function varargout = lambdarootf0(varargin)
% LAMBDAROOTF0 MATLAB code for lambdarootf0.fig
%      LAMBDAROOTF0, by itself, creates a new LAMBDAROOTF0 or raises the existing
%      singleton*.
%
%      H = LAMBDAROOTF0 returns the handle to a new LAMBDAROOTF0 or the handle to
%      the existing singleton*.
%
%      LAMBDAROOTF0('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LAMBDAROOTF0.M with the given input arguments.
%
%      LAMBDAROOTF0('Property','Value',...) creates a new LAMBDAROOTF0 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lambdarootf0_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lambdarootf0_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lambdarootf0

% Last Modified by GUIDE v2.5 14-Jan-2021 13:32:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lambdarootf0_OpeningFcn, ...
                   'gui_OutputFcn',  @lambdarootf0_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lambdarootf0 is made visible.
function lambdarootf0_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lambdarootf0 (see VARARGIN)

% Choose default command line output for lambdarootf0
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
load('lambdarootf0_matrix.mat')
%lambdarootf0_matrix=num2cell(lambdarootf0_matrix);
set(handles.lambdarootf0_gui,'Data',lambdarootf0_matrix,'ColumnEditable',true);

% UIWAIT makes lambdarootf0 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = lambdarootf0_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function lambdarootf0_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lambdarootf0_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in yes_checkbox.
function yes_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to yes_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%NUEpsilon;
 
% Hint: get(hObject,'Value') returns toggle state of yes_checkbox


% --- Executes on button press in no_checkbox.
function no_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to no_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of no_checkbox


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%global NUdelayEpsilon;
load('lambdarootf0_matrix.mat');
%load('newMatrixfor_wandz.mat');
% if get(handles.no_checkbox,'Value') == 1
% %     NUdelay0=0;
% % for k=1:1:length(lambdarootf0_matrix)
% %     if lambdarootf0_matrix(k) > 0
% %        NUdelay0=NUdelay0+1;
% %     end
% % end
% % if isempty(newMatrixfor_wandz)
% %   
% %    NUDelayFree=NUdelay0;
% %    if NUDelayFree>0
% %        disp('ϵͳ���ǲ��ȶ���');
% %        return
% %    end
% %    if NUDelayFree==0
% %        disp('ϵͳ�����ȶ���');
% %        return
% %    end
% % end
% if ~isempty(newMatrixfor_wandz)
%     CDsandPeriods=CDSandPeriods;
%     NUtau(CDsandPeriods);
%     close(lambdarootf0);
% end
% else
if get(handles.yes_checkbox,'Value') == 1 
%  if isempty(newMatrixfor_wandz)
%      NUepsilon_CDs_Periods
%    if  NUdelayEpsilon>0
%        disp('ϵͳ���ǲ��ȶ���1');
%        return
%    end
%    if  NUdelayEpsilon==0
%        disp('ϵͳ����0�������ȶ���');
%        return
%    end
% end
    
        close(lambdarootf0)
       NUepsilon_CDs_Periods
    
else
   
    CDsandPeriods=CDSandPeriods;
    NUtau(CDsandPeriods);
    %close(lambdarootf0);
   
    
end





% --- Executes when entered data in editable cell(s) in lambdarootf0_gui.
function lambdarootf0_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to lambdarootf0_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
lambdarootf0_matrix = get(hObject,'Data');
save('lambdarootf0_matrix.mat','lambdarootf0_matrix');


% --- Executes on button press in return_gui.
function return_gui_Callback(hObject, eventdata, handles)
% hObject    handle to return_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(lambdarootf0)
DeltaNUforassociated_FSCs_1
