function CDsandPeriods=CDSandPeriods
global fzlambda;
syms s w;
format long
load('newMatrixfor_wandz.mat');
newMatrixfor_wandz=cell2mat(newMatrixfor_wandz);
if ~isempty(newMatrixfor_wandz)
CDsandPeriods=[];
for n=1:1:size(newMatrixfor_wandz,1)
    omega_vector(n)=newMatrixfor_wandz(n,1);
end
%     fzlambda=[s^4+2*s^2,3,-3,1]; 
%     omega_vector=[1.9566,1];
for k=1:1:length(omega_vector)
      curretomega=omega_vector(k) ;
      fzlambda_value(k,:)=subs(fzlambda,s,curretomega*j) ;
      z(k,:)=vpa(roots(fzlambda_value(k,:)));
          abs_z(k,:)=abs(z(k,:));
          distence_z_to_1(k,:)=abs(abs_z(k,:)-1);
       [sortdistence_z_to_1(k,:) index(k,:)]=sort(distence_z_to_1(k,:));
         numberofz(k)=newMatrixfor_wandz(k,2);
       %sortdistence_z_to_1(1:numberofz(k))   
   %    effectz(k,:)=z(k,index(k,1:numberofz(k)))
end
lengthofNumberZ=length(numberofz);
MaxNumberZ=max(numberofz);
effectZ=zeros(lengthofNumberZ,MaxNumberZ);
effectAllw=zeros(lengthofNumberZ,MaxNumberZ);

for Nz=1:1:lengthofNumberZ
    effectZ(Nz,1:numberofz(Nz))=z(Nz,index(Nz,1:numberofz(Nz)));
    effectAllw(Nz,1:numberofz(Nz))=omega_vector(Nz);
end
% [omegarow,omegacol]=size(omega_vector);
% matrix=double([omega_vector,z,Deltas]);
% save matrix
[effectZrow, effectZcolumn]=size(effectZ);
for Nrow=1:1:effectZrow
   effectAllwNrowVector=effectAllw(Nrow,:);
    effectAllzNrowVector=effectZ(Nrow,:);
   not_0index=find(effectAllwNrowVector~=0);
    %numberofeffectAllwNrow=length(effectAllw(Nrow,:))
    for t=1:1:length(not_0index)
         criticalw=effectAllwNrowVector(t);
        criticalZ=effectAllzNrowVector(t);
        angZ=angle(criticalZ);
                        if angZ<=0
                            tau0=-1*angZ/criticalw;
                            period=2*pi/criticalw;
                        end
                        if angZ>0
                            tau0=(2*pi-angZ)/criticalw; 
                            period=2*pi/criticalw;
                        end
        CDsandPeriods=[CDsandPeriods,[tau0;period]];
    end
end
end
        