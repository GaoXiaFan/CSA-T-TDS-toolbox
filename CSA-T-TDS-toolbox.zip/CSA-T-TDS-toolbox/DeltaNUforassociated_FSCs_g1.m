function varargout = DeltaNUforassociated_FSCs_g1(varargin)
% DELTANUFORASSOCIATED_FSCS_G1 MATLAB code for DeltaNUforassociated_FSCs_g1.fig
%      DELTANUFORASSOCIATED_FSCS_G1, by itself, creates a new DELTANUFORASSOCIATED_FSCS_G1 or raises the existing
%      singleton*.
%
%      H = DELTANUFORASSOCIATED_FSCS_G1 returns the handle to a new DELTANUFORASSOCIATED_FSCS_G1 or the handle to
%      the existing singleton*.
%
%      DELTANUFORASSOCIATED_FSCS_G1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DELTANUFORASSOCIATED_FSCS_G1.M with the given input arguments.
%
%      DELTANUFORASSOCIATED_FSCS_G1('Property','Value',...) creates a new DELTANUFORASSOCIATED_FSCS_G1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DeltaNUforassociated_FSCs_g1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DeltaNUforassociated_FSCs_g1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DeltaNUforassociated_FSCs_g1

% Last Modified by GUIDE v2.5 02-Jun-2021 15:42:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DeltaNUforassociated_FSCs_g1_OpeningFcn, ...
                   'gui_OutputFcn',  @DeltaNUforassociated_FSCs_g1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DeltaNUforassociated_FSCs_g1 is made visible.
function DeltaNUforassociated_FSCs_g1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DeltaNUforassociated_FSCs_g1 (see VARARGIN)

% Choose default command line output for DeltaNUforassociated_FSCs_g1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
load('matrix_wanddeltaNUforassociatedFSCs_g1.mat');
set(handles.DeltaNUforassociated_FSCs_g1_gui,'Data',matrix_wanddeltaNUforassociatedFSCs_g1,'ColumnEditable',true); 


% UIWAIT makes DeltaNUforassociated_FSCs_g1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DeltaNUforassociated_FSCs_g1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(DeltaNUforassociated_FSCs_g1)
alleffectwandzforassociatedFSCs_g1


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lambdarootf0_g1;
close(DeltaNUforassociated_FSCs_g1);


% --- Executes when entered data in editable cell(s) in DeltaNUforassociated_FSCs_g1_gui.
function DeltaNUforassociated_FSCs_g1_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to DeltaNUforassociated_FSCs_g1_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_wanddeltaNUforassociatedFSCs_g1=get(hObject,'Data');
save('matrix_wanddeltaNUforassociatedFSCs_g1.mat','matrix_wanddeltaNUforassociatedFSCs_g1');
