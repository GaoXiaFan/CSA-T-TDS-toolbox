function NUtauforEpsilon
global tau_max;
global numberofgridstoNUtau;
global NUdelayEpsilon;
load('w_and_DeltaMatrix.mat');
load('matrix_wandCDsandPeriodsforEpsilon');
load('effectMatrix_wandCDsandZeros');
%effectMatrix_wandCDsandZeros=cell2mat(effectMatrix_wandCDsandZeros);
matrix_wandCDsandPeriods=[effectMatrix_wandCDsandZeros';matrix_wandCDsandPeriodsforEpsilon(3,:)];
for m=1:1:size(matrix_wandCDsandPeriods,2)
    if matrix_wandCDsandPeriods(2,m) == 0
        matrix_wandCDsandPeriods(2,m)=2*pi/matrix_wandCDsandPeriods(1,m);
    end
end
CDsandPeriodsforEpsilon=matrix_wandCDsandPeriods(2:3,:);
%CDsandPeriodsforEpsilon=CDsandPeriodsforEpsilon'
delta=w_and_DeltaMatrix(:,2);

NUtau_value=NUdelayEpsilon;
tau=0:tau_max/numberofgridstoNUtau:tau_max;
    for k=1:1:length(delta)
        NUtau_value=NUtau_value+2*delta(k)*floor(((tau+CDsandPeriodsforEpsilon(2,k)-CDsandPeriodsforEpsilon(1,k))/CDsandPeriodsforEpsilon(2,k)));
%     FinalNUtau=[FinalNUtau,NUtau_value];
    end
    


h=figure('NumberTitle','off','Name','NU Distribution');
plot(tau,NUtau_value)
xlabel('\tau')
ylabel('NU(\tau)')
AllCDsandDeltaintau_max=[];
for NumberofCD0=1:1:length(delta)
    CDs=CDsandPeriodsforEpsilon(1,NumberofCD0);
    while (CDs<tau_max)
     AllCDsandDeltaintau_max=[AllCDsandDeltaintau_max,[CDs;delta(NumberofCD0)]];
     CDs=CDs+CDsandPeriodsforEpsilon(2,NumberofCD0);
    end
end
CDsrow=AllCDsandDeltaintau_max(1,:);
Deltasrow=AllCDsandDeltaintau_max(2,:);
[CDsrow,order]=sort(CDsrow);
Deltasrow=Deltasrow(order);

 LeftMarginoftau=[];  
 RightMarginoftau=[];
 %NUdelay0=2;
 if NUtau_value==0
      LeftMarginoftau=[LeftMarginoftau,0]; 
 end
 NUtau_value(1)=NUtau_value;
 for k=1:1:length(CDsrow)
     NUtau_value(k+1)=NUtau_value(k)+2*Deltasrow(k);
%      if NUdelay0==0
%          LeftMarginoftau=[LeftMarginoftau,CDsrow(k)];
 end
for p=2:1:(k+1)
    if NUtau_value(p)==0&&NUtau_value(p-1)~=0
         LeftMarginoftau=[LeftMarginoftau,CDsrow(p-1)]; 
    end
    if NUtau_value(p)~=0&&NUtau_value(p-1)==0
        RightMarginoftau=[RightMarginoftau,CDsrow(p-1)];
    end
end
if length(LeftMarginoftau) > length(RightMarginoftau)
    RightMarginoftau=[RightMarginoftau,tau_max];
end
NumberofStabilityIntervals=length(RightMarginoftau);
 fprintf('Results of complete stability analysis by CSA-T-TDS Toolbox:\n')
 fprintf('\t\t The number of stability delay-intervals is %d.\n',NumberofStabilityIntervals)
 if NumberofStabilityIntervals~=0
     
     fprintf('\t\t The stability delay-interval(s) is(are):\n');
    if LeftMarginoftau(1)==0
        fprintf('\t\t [0,%.4f)\n',RightMarginoftau(1));
       for KLeftMarginoftau1=2:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau1),RightMarginoftau(KLeftMarginoftau1));
       end
    else
        for KLeftMarginoftau2=1:1:length(LeftMarginoftau)
    %       for Kinterval=1:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau2),RightMarginoftau(KLeftMarginoftau2));
        end
    end 
 end
     fprintf('\t\t For ''NU vs.tau'' plot, please see Figure ''NU Distribution''.\n') 
