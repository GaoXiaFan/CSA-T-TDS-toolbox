function main
close all;
clc;
global lengtha0;
global lengtha1toaq;
global q;

% load ('lambdarootf0_matrix');
% lambdarootf0_matrix=[];
% save lambdarootf0_matrix;
% load ('coeMatrix');
% coeMatrix=[];
% save coeMatrix;
% load ('smatrix');
% smatrix=[];
% save smatrix;
% load ('matrix');
% matrix=[];
% save matrix;
% load ('matrix_alleffectwandzforassociatedFSCs');
% matrix_alleffectwandzforassociatedFSCs=[];
% save matrix_alleffectwandzforassociatedFSCs;
% load ('matrix_number_of_associated_FSCs');
% matrix_number_of_associated_FSCs=[];
% save matrix_number_of_associated_FSCs;
% 
% load ('matrix_wanddeltaNUforassociatedFSCs');
% matrix_wanddeltaNUforassociatedFSCs=[];
% save matrix_wanddeltaNUforassociatedFSCs;
% 
% load ('matrix_wandCDsandZeros');
% matrix_wandCDsandZeros=[];
% save matrix_wandCDsandZeros;
% load ('matrix_wandCDsandPeriodsforEpsilon');
% matrix_wandCDsandPeriodsforEpsilon=[];
% save matrix_wandCDsandPeriodsforEpsilon;
% load ('matrixOriginal');
% matrixOriginal=[];
% save matrixOriginal;
% load ('newMatrix');
% newMatrix=[];
% save newMatrix;
% load ('newMatrixfor_wandz');
% newMatrixfor_wandz=[];
% save newMatrixfor_wandz;
% load ('w_and_DeltaMatrix');
% w_and_DeltaMatrix=[];
% save w_and_DeltaMatrix;



disp('******** CSA-T-TDS Toolbox ********');
disp('Please input the following information:');
 q=input('q='); 
%% ����f(lambda,z)�ı���ʽ
[coeMatrix]=coefficientMatrix(q);%ϵ������
save coeMatrix;

syms s;
[row,col]=size(coeMatrix);
    smatrix=[];
    while col~=0   
        
        smatrix=[smatrix s^(col-1)];  %��Ӧs����
        col=col-1;
    end
    save smatrix;
if lengtha0>max(lengtha1toaq)
    disp('The time-delay system is of the retarded type.');
    settingsfor_toolbox;
    return;
elseif lengtha0==max(lengtha1toaq)
    disp('The time-delay system is of the neutral type.'); 
    settingsfor_toolbox;
    return;
elseif lengtha0<max(lengtha1toaq)
    disp('The time-delay system is of the advanced type.');
    return;
end
       
%      tau_max=input('tau_max=');
%      omega_max=input('omega_max=');    %����
%      numberofgrids=input('numberofgrids=');    %����                                                                                                                    
%     [row,col]=size(coeMatrix);
%     smatrix=[];
%     while col~=0
%         sym s;
%         smatrix=[smatrix s^(col-1)];  %��Ӧs����
%         col=col-1;
%     end
%     fzlambda=smatrix*coeMatrix'; %����ʽ
%     fzlambda=fliplr(fzlambda);
%     %sigma_precisionbound=1e-8;
%     z_precisionbound=1e-8;
%     %% ��Ƶ��ɨ��ͼ
%     frequencycurve(fzlambda);
%     flambda=subs(fzlambda,s,j*w);
%     [matrix,matrixOriginal]=fuzhu(flambda) ;  
%     NUdelay0;
%     W_Roots;






