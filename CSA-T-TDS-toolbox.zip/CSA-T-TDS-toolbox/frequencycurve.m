 function frequencycurve(numberofgrids,omega_max)
 global fzlambda;
 global q;
 global h;
 global lengtha0;
 global lengtha1toaq;
 
 if q==1
  figure('NumberTitle','off','Name','Frequency-Sweeping Curve');
end
if q>1
    figure('NumberTitle','off','Name','Frequency-Sweeping Curves');
end

hold on 
syms s w; 
FSComega=zeros(numberofgrids,1);
for Nz=1:1:q
 z(:,Nz)=zeros(numberofgrids,1);
end
n=length(fzlambda);
strfzlambda = '@(s)roots([';
for i=1:1:n
    fzlambdaroot=fzlambda(1,i);
   fzlambdaroot=char(fzlambdaroot);
    str = sprintf('(%s)\t',fzlambdaroot);   
    strfzlambda = [strfzlambda str];
end
str = ']);';

strfzlambda = [strfzlambda str];
strfzlambda=eval(strfzlambda);
% Allw=[];
w_frequencycurve = 0;
for n=1:1:numberofgrids
    w_frequencycurve=omega_max*n/numberofgrids;
%     Allw=[Allw,w_frequencycurve];
    r=strfzlambda(j*w_frequencycurve);
   for Nr=1:1:length(r)
     Normr(Nr)=norm(r(Nr,1));
   end
    R=sort(Normr);
    NR=length(R);  
   for NR=1:1:length(R)
     z(n,NR)=R(1,NR);
   end
    FSComega(n,1)=w_frequencycurve;
end

plot(FSComega,z,'k') 
plot([0 w_frequencycurve],[1 1],'b')
xlabel('\omega')
if q==1
   ylabel('\Gamma_{1}')
end
if q==2
   ylabel('\Gamma_{1}, \Gamma_{2}')
end
if q==3
   ylabel('\Gamma_{1},\Gamma_{2}, \Gamma_{3}')
end
if q>3
   ylabel('\Gamma_{1...}')
end
% axis([0 omega_max,0 omega_max])

h = figure(1);
if lengtha0==max(lengtha1toaq)
    operator;
    return;
end

    flambda=subs(fzlambda,s,j*w);
    [matrix,matrixOriginal]=auxiliaryequation(flambda) ;
    NUdelay0;
    W_Roots;