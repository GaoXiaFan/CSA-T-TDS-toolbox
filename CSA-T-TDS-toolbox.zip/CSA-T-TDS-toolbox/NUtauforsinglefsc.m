function NUtau(CDsandPeriods)
global tau_max;
global numberofgridstoNUtau;
load('matrix_wanddeltaNUforassociatedFSCs_g1.mat');
load('lambdarootf0_matrix.mat');
matrix_wanddeltaNUforassociatedFSCs_g1=cell2mat(matrix_wanddeltaNUforassociatedFSCs_g1);
 delta=matrix_wanddeltaNUforassociatedFSCs_g1(:,2);
% w_matrix = w_and_DeltaMatrix(:,1);
load('matrix_wAndNumberOfCriticalPairs.mat');
 if ~isempty(matrix_wAndNumberOfCriticalPairs)
 matrix_wAndNumberOfCriticalPairs = cell2mat(matrix_wAndNumberOfCriticalPairs);
sumColumns= sum(matrix_wAndNumberOfCriticalPairs(:,2));
 matrix_w=zeros(1,sumColumns);
 m=1;
 for k=1:1:size(matrix_wAndNumberOfCriticalPairs,1)
     if matrix_wAndNumberOfCriticalPairs(k,2) == 1
         matrix_w(1,m)=matrix_wAndNumberOfCriticalPairs(k,1);
         m=m+1;
     end
     if matrix_wAndNumberOfCriticalPairs(k,2) ~= 1
         matrix_w(1,m:m+matrix_wAndNumberOfCriticalPairs(k,2)-1)=matrix_wAndNumberOfCriticalPairs(k,1);
         m=m+matrix_wAndNumberOfCriticalPairs(k,2);
     end
 end
 end
matrix_wandCDsandPeriods=[matrix_w;CDsandPeriods];
for m=1:1:size(matrix_wandCDsandPeriods,2)
    if matrix_wandCDsandPeriods(2,m) == 0
       matrix_wandCDsandPeriods(2,m)=2*pi/matrix_wandCDsandPeriods(1,m);
    end
end
% [FinalNUtau;tau]=[];
NUdelay0=0;
for k=1:1:length(lambdarootf0_matrix)
    if lambdarootf0_matrix(k) > 0
       NUdelay0=NUdelay0+1;
    end
end
NUtau_value=NUdelay0;
% FinalNUtau=[FinalNUtau,NUtau_value];
tau=0:tau_max/numberofgridstoNUtau:tau_max;
    for k=1:1:length(delta)
        NUtau_value=NUtau_value+2*delta(k)*floor(((tau+CDsandPeriods(2,k)-CDsandPeriods(1,k))/CDsandPeriods(2,k)));
%     FinalNUtau=[FinalNUtau,NUtau_value];
    end

h=figure('NumberTitle','off','Name','NU Distribution');
plot(tau,NUtau_value)
xlabel('\tau')
ylabel('NU(\tau)')
LeftMarginoftau=[];  
    RightMarginoftau=[];
for KNU=1:1:(length(NUtau_value)-1)
    if NUtau_value(KNU)==0&&NUtau_value(KNU+1)>0
        RightMarginoftau=[RightMarginoftau,tau(KNU+1)];
    end
     if NUtau_value(KNU)>0&&NUtau_value(KNU+1)==0
        LeftMarginoftau=[LeftMarginoftau,tau(KNU)];
     end
end
NumberofStabilityIntervals=length(RightMarginoftau);
 fprintf('Results of complete stability analysis by CSA-T-TDS Toolbox:\n')
 fprintf('\t\t The number of stability delay-intervals is %d.\n',NumberofStabilityIntervals)
 if NumberofStabilityIntervals~=0
     fprintf('\t\t The stability delay-interval(s) is(are):\n');
    if NUtau_value(1)==0
        fprintf('\t\t [0,%.4f)\n',RightMarginoftau(1));
       for KLeftMarginoftau1=1:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau1),RightMarginoftau(KLeftMarginoftau1+1));
       end
    else
        for KLeftMarginoftau2=1:1:length(LeftMarginoftau)
    %       for Kinterval=1:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau2),RightMarginoftau(KLeftMarginoftau2));
        end
    end 
 end
     fprintf('\t\t For ''NU vs.tau'' plot, please see Figure ''NU Distribution''.\n')
     
     
     
     
     
     
  function NUtau(CDsandPeriods)
global tau_max;
global numberofgridstoNUtau;
load('w_and_DeltaMatrix.mat');
load('lambdarootf0_matrix.mat');

 delta=w_and_DeltaMatrix(:,2);
 load('newMatrixfor_wandz.mat');
% w_matrix = w_and_DeltaMatrix(:,1);

 if ~isempty(newMatrixfor_wandz)
newMatrixfor_wandz = cell2mat(newMatrixfor_wandz);
sumColumns= sum(newMatrixfor_wandz(:,2));
 matrix_w=zeros(1,sumColumns);
 m=1;
 for k=1:1:size(newMatrixfor_wandz,1)
     if newMatrixfor_wandz(k,2) == 1
         matrix_w(1,m)=newMatrixfor_wandz(k,1);
         m=m+1;
     end
     if newMatrixfor_wandz(k,2) ~= 1
         matrix_w(1,m:m+newMatrixfor_wandz(k,2)-1)=newMatrixfor_wandz(k,1);
         m=m+newMatrixfor_wandz(k,2);
     end
 end
 end
matrix_wandCDsandPeriods=[matrix_w;CDsandPeriods];
for m=1:1:size(matrix_wandCDsandPeriods,2)
    if matrix_wandCDsandPeriods(2,m) == 0
       matrix_wandCDsandPeriods(2,m)=2*pi/matrix_wandCDsandPeriods(1,m);
    end
end
% [FinalNUtau;tau]=[];
NUdelay0=0;
for k=1:1:length(lambdarootf0_matrix)
    if lambdarootf0_matrix(k) > 0
       NUdelay0=NUdelay0+1;
    end
end
NUtau_value=NUdelay0;
% FinalNUtau=[FinalNUtau,NUtau_value];
tau=0:tau_max/numberofgridstoNUtau:tau_max;
    for k=1:1:length(delta)
        NUtau_value=NUtau_value+2*delta(k)*floor(((tau+CDsandPeriods(2,k)-CDsandPeriods(1,k))/CDsandPeriods(2,k)));
%     FinalNUtau=[FinalNUtau,NUtau_value];
    end

h=figure('NumberTitle','off','Name','NU Distribution');
plot(tau,NUtau_value)
xlabel('\tau')
ylabel('NU(\tau)')
LeftMarginoftau=[];  
    RightMarginoftau=[];
for KNU=1:1:(length(NUtau_value)-1)
    if NUtau_value(KNU)==0&&NUtau_value(KNU+1)>0
        RightMarginoftau=[RightMarginoftau,tau(KNU+1)];
    end
     if NUtau_value(KNU)>0&&NUtau_value(KNU+1)==0
        LeftMarginoftau=[LeftMarginoftau,tau(KNU)];
     end
end
NumberofStabilityIntervals=length(RightMarginoftau);
 fprintf('Results of complete stability analysis by CSA-T-TDS Toolbox:\n')
 fprintf('\t\t The number of stability delay-intervals is %d.\n',NumberofStabilityIntervals)
 if NumberofStabilityIntervals~=0
     fprintf('\t\t The stability delay-interval(s) is(are):\n');
    if NUtau_value(1)==0
        fprintf('\t\t [0,%.4f)\n',RightMarginoftau(1));
       for KLeftMarginoftau1=1:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau1),RightMarginoftau(KLeftMarginoftau1+1));
       end
    else
        for KLeftMarginoftau2=1:1:length(LeftMarginoftau)
    %       for Kinterval=1:1:length(LeftMarginoftau)
            fprintf('\t\t (%.4f,%.4f)\n',LeftMarginoftau(KLeftMarginoftau2),RightMarginoftau(KLeftMarginoftau2));
        end
    end 
 end
     fprintf('\t\t For ''NU vs.tau'' plot, please see Figure ''NU Distribution''.\n')
 