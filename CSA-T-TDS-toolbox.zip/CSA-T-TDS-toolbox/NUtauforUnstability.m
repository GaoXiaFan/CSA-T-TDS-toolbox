function NUtauforUnstability(NUdelay0)
global tau_max;
global numberofgridstoNUtau;
tau=0:tau_max/numberofgridstoNUtau:tau_max;
NUtau_value=NUdelay0+0*tau;
figure('NumberTitle','off','Name','NU Distribution');
plot(tau,NUtau_value)
xlabel('\tau')
ylabel('NU(\tau)')