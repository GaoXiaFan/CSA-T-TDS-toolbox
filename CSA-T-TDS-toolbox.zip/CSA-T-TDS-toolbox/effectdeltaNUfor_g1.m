function deltaNU=effectdeltaNUfor_g1
global fzlambda;
global omega_max;
global numberofgridstoFSC;
global q;
load('matrix_alleffectwandzforassociatedFSCs_g1.mat');
%load('matrix_wAndNumberOfCriticalPairs.mat');
load('matrix_number_of_associated_FSCs.mat');
matrix_w=matrix_alleffectwandzforassociatedFSCs_g1(:,1);
matrix_w=cell2mat(matrix_w);
matrix_alleffectwandzforassociatedFSCs_g1=cell2mat(matrix_alleffectwandzforassociatedFSCs_g1);
%matrix_wAndNumberOfCriticalPairs=cell2mat(matrix_wAndNumberOfCriticalPairs);
matrix_number_of_associated_FSCs=cell2mat(matrix_number_of_associated_FSCs);
%matrix_modForwandnumber_of_associated_FSCs�������ű任λ�ú��omega�����Ӧ��fsc����
matrix_modForwandnumber_of_associated_FSCs=zeros(size(matrix_number_of_associated_FSCs,1),size(matrix_number_of_associated_FSCs,2));
for i=1:1:length(matrix_w)
    matrix_modForwandnumber_of_associated_FSCs(i,1)=matrix_w(i);
    for p=1:1:size(matrix_number_of_associated_FSCs,1)
        if matrix_w(i)==matrix_number_of_associated_FSCs(p,1)
            matrix_modForwandnumber_of_associated_FSCs(i,2)=matrix_number_of_associated_FSCs(p,2);
        end
    end
end
    
%matrix_w=matrix_wAndNumberOfCriticalPairs(:,1)

%matrix_w=matrix_alleffectwandzforassociatedFSCs_g1(:,1);

% %fzlambda=z^2+(s^2+1)*z+s^4-2
% fzlambda=[1, -s^2+5,8-s^2,-s^3-3*s^2-s+1];
% %fzlambda=[1, -s^2+8,27,-31,s^4+11];
% %fzlambda=[1, -s^2+1,s^6-s^5+s+2];
syms s;
deltaNU = [];
for m=1:1:length(matrix_w)
    firstfsc=0;
    nextfsc=0;
     curretomega=matrix_w(m) ;
       fzlambda_vector=(subs(fzlambda,s,curretomega*j));
       fzlambda_vectorleft=(subs(fzlambda,s,(curretomega-omega_max/numberofgridstoFSC)*j));
       fzlambda_vectorright=(subs(fzlambda,s,(curretomega+omega_max/numberofgridstoFSC)*j));
       z=vpa(roots(fzlambda_vector));
       zleft=vpa(roots(fzlambda_vectorleft));
       zright=vpa(roots(fzlambda_vectorright));
       abs_z=abs(z);
       distence_z_to_1=abs(abs_z-1);
        [sortdistence_z_to_1 , index]=sort(distence_z_to_1);
        effectz=z(index(1:matrix_modForwandnumber_of_associated_FSCs(m,2)));
        
        nearzleft=zeros(q,1);
        nearzright=zeros(q,1);
        for zleftindex=1:1:length(zleft)
            for k = 1:1:length(effectz)
                nearzleft(zleftindex,:)= nearzleft(zleftindex,:) + abs(zleft(zleftindex)-effectz(k));
            end
        end       
       for zrightindex=1:1:length(zright)
            for k = 1:1:length(effectz)
                nearzright(zrightindex,:)= nearzright(zrightindex,:) + abs(zright(zrightindex)-effectz(k));
            end
        end
        [sortnearzleft,indexnearzleft]=sort(nearzleft);
        [sortnearzright,indexnearzright]=sort(nearzright);
        effectzleft=zleft(indexnearzleft(1:matrix_modForwandnumber_of_associated_FSCs(m,2)));
        effectzright=zright(indexnearzright(1:matrix_modForwandnumber_of_associated_FSCs(m,2)));
        %���¼���deltaNU
        for numzleft=1:1:length(effectzleft)
           if abs(effectzleft(numzleft)) > 1
               firstfsc = firstfsc + 1;
           end
           if abs(effectzleft(numzleft)) < 1
              firstfsc = firstfsc - 1;
           end
        end
        for numzright=1:1:length(effectzright)
           if abs(effectzright(numzright)) > 1
               nextfsc = nextfsc + 1;
           end
           if abs(effectzright(numzright)) < 1
              nextfsc = nextfsc - 1;
           end
        end
         deltaNU=[deltaNU,(nextfsc-firstfsc) / 2]  ;     
end


 
