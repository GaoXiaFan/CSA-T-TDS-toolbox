function varargout = W_Roots(varargin)
% W_ROOTS MATLAB code for W_Roots.fig
%      W_ROOTS, by itself, creates a new W_ROOTS or raises the existing
%      singleton*.
%
%      H = W_ROOTS returns the handle to a new W_ROOTS or the handle to
%      the existing singleton*.
%
%      W_ROOTS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in W_ROOTS.M with the given input arguments.
%
%      W_ROOTS('Property','Value',...) creates a new W_ROOTS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before W_Roots_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to W_Roots_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help W_Roots

% Last Modified by GUIDE v2.5 15-Mar-2021 09:33:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @W_Roots_OpeningFcn, ...
                   'gui_OutputFcn',  @W_Roots_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before W_Roots is made visible.
function W_Roots_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to W_Roots (see VARARGIN)

% Choose default command line output for W_Roots
global rowIndex;
 handles.output = hObject;
% % Update handles structure
 guidata(hObject, handles);
 %set(gcf,'NumberTitle', 'off','Name','W Roots');
%  axis off;
 rowIndex=[];
load('matrix.mat');
%matrix=num2cell(matrix);
load('matrixOriginal.mat');
matrixOriginal=num2cell(matrixOriginal);
matrix=matrixOriginal;
%matrix = num2cell(matrix);
set(handles.matrixdatatable_gui,'Data',matrixOriginal,'ColumnEditable',true);
save('matrix.mat','matrix');
% set(handles.matrixdatatable_gui,'Data',logicalvector,'ColumnEditable',true,'ColumnFormat',logical);
% UIWAIT makes W_Roots wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = W_Roots_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in addEle_gui.


% --- Executes on button press in merge_gui.
function merge_gui_Callback(hObject, eventdata, handles)
% hObject    handle to merge_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
rowIndex=[];
effectrowIndex = handles.effectrowIndex;
matrix = get(handles.matrixdatatable_gui,'Data');
matrix=matrix(:,[1,2]);     %��ȡ�������ݾ���
matrix=cell2mat(matrix);
mergeData = matrix(effectrowIndex,:);
%round(a*2)/2
% matrix(effectrowIndex(1),1) = sum(mergeData(:,1))/size(mergeData,1);
matrix(effectrowIndex(1),1) = mean(mergeData(:,1));
matrix(effectrowIndex(1),2) = sqrt(matrix(effectrowIndex(1),1));
for k=2:length(effectrowIndex)
    matrix(effectrowIndex(k),:) = [];
end
matrix=[matrix,zeros(size(matrix,1),1)];
matrix=num2cell(matrix);
set(handles.matrixdatatable_gui,'Data',matrix); 
 save('matrix.mat','matrix');  %����һ������


% --- Executes when entered data in editable cell(s) in matrixtable_gui.

% --- Executes when selected cell(s) is changed in matrixdatatable_gui.
function matrixdatatable_gui_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to matrixdatatable_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
effectrowIndex=[];
hang = eventdata.Indices(:,1);%��ȡ������
if isempty(hang)  
     return
end
if eventdata.Indices(2)==3%���ѡ����ǵ�����checkbox������в���
%                 event.Source.Data(event.Indices(1),event.Indices(2))
%                 �������data�н���һ�У����ã����������data�Ǿ���������ʹ��{}
      if eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2) }                
         eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)}=false;
      else
          eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)} =true;
      end
end
matrix = get(hObject,'Data');       %��ȡ���ݾ���
 selectIndex={1};           %��������б�ѡ��Ϊ1���ǲ�Ҫ���������
    rowIndex =[rowIndex,hang];          %��������ֵ
   for m=1:1:length(rowIndex)
        if isequal(matrix(rowIndex(m),3),selectIndex)
            effectrowIndex =[effectrowIndex,rowIndex(m)];%��������ֵ
        end
  end
  effectrowIndex=sort(unique(effectrowIndex));
   rowIndex=effectrowIndex;
handles.effectrowIndex = effectrowIndex;             %�����������ӵ��ṹ��
 guidata(hObject, handles); 
            
% --- Executes during object creation, after setting all properties.
function matrixdatatable_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to matrixdatatable_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in split_gui.
% function split_gui_Callback(hObject, eventdata, handles)
% % hObject    handle to split_gui (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% global rowIndex;
% rowIndex=[];
% effectrowIndex = handles.effectrowIndex;
% matrix = get(handles.matrixdatatable_gui,'Data'); 
% matrix=matrix(:,[1,2]);            %��ȡ�������ݾ���
% matrix=cell2mat(matrix);
% splitData = matrix(effectrowIndex,:);               %��ȡ�������
% splitData1_1=splitData(1)-0.00000000000001;
% splitData1_2=sqrt(splitData1_1);
% splitData2_1=splitData(1)+0.00000000000001;
% splitData2_2=sqrt(splitData2_1);
% splitData1=[splitData1_1,splitData1_2];
% splitData2=[splitData2_1,splitData2_2];
% oldData = get(handles.matrixdatatable_gui,'Data');       %����ԭ��������
% oldData=oldData(:,[1,2]);
% oldData=cell2mat(oldData);
% matrix = [oldData;splitData1;splitData2];  %�µ�����Դ
% matrix(effectrowIndex,:) = [];
% matrix=[matrix,zeros(size(matrix,1),1)];
% matrix=num2cell(matrix);
% set(handles.matrixdatatable_gui,'Data',matrix);  %��ʾ��������
% %handles.tabale = newData;
% save('matrix.mat','matrix'); %�����������Ա��棬�����´�ʹ��


% --- Executes on button press in original_gui.
% function original_gui_Callback(hObject, eventdata, handles)
% % hObject    handle to original_gui (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
%  handles.output = hObject;
% 
% % Update handles structure
% guidata(hObject, handles);
% 
% load('matrixOriginal.mat');
% matrixOriginal=num2cell(matrixOriginal);
% set(handles.matrixdatatable_gui,'Data',matrixOriginal,'ColumnEditable',true);

% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.no_gui,'Value') == 1 
    NU0forNoCriticalRoots;
   close(W_Roots);
else
    global rowIndex;
    rowIndex=[];
    effectrowIndex = handles.effectrowIndex;
    matrix = get(handles.matrixdatatable_gui,'Data'); 
    matrix=matrix(:,[1,2])  ;      %��ȡ�������ݾ���
    % matrix=cell2mat(matrix);
    newMatrix = matrix(effectrowIndex,:);
    newMatrix=newMatrix(:,2);
     newMatrix=cell2mat(newMatrix);
        newMatrix_column2=ones(length(newMatrix),1);
%         for k=1:1:length(newMatrix)
%             newMatrix_column2(k)=1;
%         end
        newMatrix=[newMatrix,newMatrix_column2];
        newMatrix=num2cell(newMatrix);
    save('newMatrix.mat','newMatrix');
        close(W_Roots);
        number_of_associated_FSCs
end


% --- Executes when entered data in editable cell(s) in matrixdatatable_gui.
function matrixdatatable_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to matrixdatatable_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix = get(hObject,'Data');
save('matrix.mat','matrix');



% --- Executes on button press in ok_gui.
function ok_gui_Callback(hObject, eventdata, handles)
% hObject    handle to ok_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%rowIndex = handles.rowIndex;
% matrix = get(handles.matrixdatatable_gui,'Data')
% [matrixrow,matrixcolumn]=size(matrix)
% % while (size(matrix,1)>0)
% effectVector=[];
% for k=1:matrixrow
%     if( matrix(k,3) == 1)
%         k
%      effectVector=[effectVector;matrix(k,:)]
%     end
% end
% save effectVector
% for l=1:length(deleteVector)
%     matrix(l,:)=[];
% end
% while (k <= (c=find(matrix())))
%     k=1;
%      if( matrix(k,3) == 0)
%          matrix(k,:)=[]
%      else
%          k = k + 1
%      end
% end
% set(handles.matrixdatatable_gui,'Data',matrix);  %��ʾ��������
% %handles.tabale = newData;
% save('matrix.mat','matrix'); %�����������Ա��棬�����´�ʹ��


% --- Executes on button press in no_gui.
function no_gui_Callback(hObject, eventdata, handles)
% hObject    handle to no_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of no_gui


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global lengtha0;
global lengtha1toaq;
global h;
if lengtha0>max(lengtha1toaq)
   settingsfor_toolbox; 
   close(h)
end
if lengtha0==max(lengtha1toaq)
    operator;
end
close(W_Roots);
