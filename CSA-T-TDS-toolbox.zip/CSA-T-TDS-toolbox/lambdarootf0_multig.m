function varargout = lambdarootf0_multig(varargin)
% LAMBDAROOTF0_MULTIG MATLAB code for lambdarootf0_multig.fig
%      LAMBDAROOTF0_MULTIG, by itself, creates a new LAMBDAROOTF0_MULTIG or raises the existing
%      singleton*.
%
%      H = LAMBDAROOTF0_MULTIG returns the handle to a new LAMBDAROOTF0_MULTIG or the handle to
%      the existing singleton*.
%
%      LAMBDAROOTF0_MULTIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LAMBDAROOTF0_MULTIG.M with the given input arguments.
%
%      LAMBDAROOTF0_MULTIG('Property','Value',...) creates a new LAMBDAROOTF0_MULTIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lambdarootf0_multig_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lambdarootf0_multig_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lambdarootf0_multig

% Last Modified by GUIDE v2.5 14-Jun-2021 14:06:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lambdarootf0_multig_OpeningFcn, ...
                   'gui_OutputFcn',  @lambdarootf0_multig_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lambdarootf0_multig is made visible.
function lambdarootf0_multig_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lambdarootf0_multig (see VARARGIN)

% Choose default command line output for lambdarootf0_multig
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes lambdarootf0_multig wait for user response (see UIRESUME)
% uiwait(handles.figure1);
load('lambdarootf0_matrix.mat')
set(handles.lambdarootf0_multig_gui,'Data',lambdarootf0_matrix,'ColumnEditable',true);


% --- Outputs from this function are returned to the command line.
function varargout = lambdarootf0_multig_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when entered data in editable cell(s) in lambdarootf0_multig_gui.
function lambdarootf0_multig_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to lambdarootf0_multig_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in yes_checkbox.
function yes_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to yes_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of yes_checkbox


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(lambdarootf0_multig)
DeltaNUforassociated_FSCs_multig

% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load('lambdarootf0_matrix.mat');
if get(handles.yes_checkbox,'Value') == 1 
       close(lambdarootf0_multig)
       NUepsilon_CDs_Periods_multig  
else
   
    CDsandPeriods=CDSandPeriods_multig;
    NUtau_multig(CDsandPeriods);
    %close(lambdarootf0_multig);
   
    
end
