function CDsandPeriods=CDSandPeriods_multig
load('matrix_alleffectwandzforassociatedFSCs_multig.mat');
matrix_alleffectwandzforassociatedFSCs_multig=cell2mat(matrix_alleffectwandzforassociatedFSCs_multig);
CDsandPeriods=[];

    for t=1:1:size(matrix_alleffectwandzforassociatedFSCs_multig,1)
         criticalw=matrix_alleffectwandzforassociatedFSCs_multig(t,1);
        criticalZ=matrix_alleffectwandzforassociatedFSCs_multig(t,2);
        angZ=angle(criticalZ);
                        if angZ<=0
                            tau0=-1*angZ/criticalw;
                            period=2*pi/criticalw;
                        end
                        if angZ>0
                            tau0=(2*pi-angZ)/criticalw; 
                            period=2*pi/criticalw;
                        end
        CDsandPeriods=[CDsandPeriods,[tau0;period]];
    end


        