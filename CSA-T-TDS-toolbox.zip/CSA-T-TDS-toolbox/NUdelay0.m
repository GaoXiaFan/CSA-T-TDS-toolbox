function NUdelay0
syms s;
global fzlambda
lambdarootf0_matrix=[];
fdelay0=0;
for k=1:1:length(fzlambda)
   fdelay0=fdelay0+fzlambda(k);
end
coefdelay0= poly_coeffs(fdelay0,'s');
coefdelay0 = fliplr(coefdelay0);
lambdarootf0=roots(coefdelay0);
lambdarootf0_matrix=[double(lambdarootf0),lambdarootf0_matrix];

save lambdarootf0_matrix;


