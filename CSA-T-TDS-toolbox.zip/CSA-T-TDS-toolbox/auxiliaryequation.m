function [matrix,matrixOriginal]=auxiliaryequation(flambda)
% effectw=[]; 
format long
hold on
syms  w W;
% z=[];
%fzlambda=fzlambda;
lengthflambda=length(flambda);
k=lengthflambda;
for r=1:1:k-1

for Currentk=1:1:k
   flambda(r+1,Currentk)=subs(flambda(r,1),w,-w)*flambda(r,Currentk)-flambda(r,k)*subs(flambda(r,k-Currentk+1),w,-w);
end
    if k>=2
  k=k-1;
end
end
Fw=flambda(lengthflambda,1);
Fw=collect(Fw);
CoeFw=sym2poly(Fw);
lengthFw=length(CoeFw);
CoeFW=[];
for l=1:2:lengthFw

CoeFW=[CoeFW,CoeFw(1,l)];
end
% FW=poly2sym(CoeFW,W)
% DiffFW=diff(FW,W)
WRoots=roots(CoeFW);
real_id=~imag(WRoots);
sort_real_WRoots=sort(WRoots(real_id));
complex_WRoots=WRoots(~real_id);
compleximag_WRoots=imag(complex_WRoots);
[sortcompleximag_WRoots, index]= sort(abs(compleximag_WRoots));
sort_complex_WRoots=complex_WRoots(index);
%sort_complex_WRoots=sort(complex_WRoots);
WRoots=[sort_real_WRoots;sort_complex_WRoots];
wRoots=sqrt(WRoots);
matrix=double([WRoots,wRoots]);

[matrixRow,matrixColumn]=size(matrix);
matrix=[matrix,zeros(matrixRow,1)];
matrixOriginal=matrix;
save matrix
 save matrixOriginal
end