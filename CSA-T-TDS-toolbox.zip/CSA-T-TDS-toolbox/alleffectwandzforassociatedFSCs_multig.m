function varargout = alleffectwandzforassociatedFSCs_multig(varargin)
% ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG MATLAB code for alleffectwandzforassociatedFSCs_multig.fig
%      ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG, by itself, creates a new ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG or raises the existing
%      singleton*.
%
%      H = ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG returns the handle to a new ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG or the handle to
%      the existing singleton*.
%
%      ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG.M with the given input arguments.
%
%      ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG('Property','Value',...) creates a new ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before alleffectwandzforassociatedFSCs_multig_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to alleffectwandzforassociatedFSCs_multig_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help alleffectwandzforassociatedFSCs_multig

% Last Modified by GUIDE v2.5 14-Jun-2021 13:43:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @alleffectwandzforassociatedFSCs_multig_OpeningFcn, ...
                   'gui_OutputFcn',  @alleffectwandzforassociatedFSCs_multig_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before alleffectwandzforassociatedFSCs_multig is made visible.
function alleffectwandzforassociatedFSCs_multig_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to alleffectwandzforassociatedFSCs_multig (see VARARGIN)

% Choose default command line output for alleffectwandzforassociatedFSCs_multig
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes alleffectwandzforassociatedFSCs_multig wait for user response (see UIRESUME)
% uiwait(handles.figure1);
load('matrix_alleffectwandzforassociatedFSCs_multig.mat');
set(handles.alleffectwandzforassociatedFSCs_multig_gui,'Data',matrix_alleffectwandzforassociatedFSCs_multig,'ColumnEditable',true);


% --- Outputs from this function are returned to the command line.
function varargout = alleffectwandzforassociatedFSCs_multig_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(alleffectwandzforassociatedFSCs_multig)
selectzforassociatedFSCs_multig

% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load('matrix_alleffectwandzforassociatedFSCs_multig.mat');
matrix_alleffectw=matrix_alleffectwandzforassociatedFSCs_multig(:,1);
matrix_alleffectw=cell2mat(matrix_alleffectw);
deltaNU=effectdeltaNUfor_multig ;
matrix_wanddeltaNUforassociatedFSCs_multig=[matrix_alleffectw,deltaNU'];
save('matrix_wanddeltaNUforassociatedFSCs_multig.mat','matrix_wanddeltaNUforassociatedFSCs_multig')
DeltaNUforassociated_FSCs_multig;
close(alleffectwandzforassociatedFSCs_multig)

% --- Executes when entered data in editable cell(s) in alleffectwandzforassociatedFSCs_multig_gui.
function alleffectwandzforassociatedFSCs_multig_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to alleffectwandzforassociatedFSCs_multig_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_alleffectwandzforassociatedFSCs_multig = get(hObject,'Data');
save('matrix_alleffectwandzforassociatedFSCs_multig.mat','matrix_alleffectwandzforassociatedFSCs_multig');
