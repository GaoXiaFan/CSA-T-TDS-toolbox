function varargout = selectzforassociatedFSCs_multig(varargin)
% SELECTZFORASSOCIATEDFSCS_MULTIG MATLAB code for selectzforassociatedFSCs_multig.fig
%      SELECTZFORASSOCIATEDFSCS_MULTIG, by itself, creates a new SELECTZFORASSOCIATEDFSCS_MULTIG or raises the existing
%      singleton*.
%
%      H = SELECTZFORASSOCIATEDFSCS_MULTIG returns the handle to a new SELECTZFORASSOCIATEDFSCS_MULTIG or the handle to
%      the existing singleton*.
%
%      SELECTZFORASSOCIATEDFSCS_MULTIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECTZFORASSOCIATEDFSCS_MULTIG.M with the given input arguments.
%
%      SELECTZFORASSOCIATEDFSCS_MULTIG('Property','Value',...) creates a new SELECTZFORASSOCIATEDFSCS_MULTIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before selectzforassociatedFSCs_multig_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to selectzforassociatedFSCs_multig_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help selectzforassociatedFSCs_multig

% Last Modified by GUIDE v2.5 09-Jun-2021 10:00:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @selectzforassociatedFSCs_multig_OpeningFcn, ...
                   'gui_OutputFcn',  @selectzforassociatedFSCs_multig_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before selectzforassociatedFSCs_multig is made visible.
function selectzforassociatedFSCs_multig_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to selectzforassociatedFSCs_multig (see VARARGIN)

% Choose default command line output for selectzforassociatedFSCs_multig
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes selectzforassociatedFSCs_multig wait for user response (see UIRESUME)
% uiwait(handles.figure1);
global rowIndex;
rowIndex=[];
load('matrix_wandzandgforassociatedFSCs_multig.mat');
set(handles.selectzforassociatedFSCs_multig_gui,'Data',matrix_wandzandgforassociatedFSCs_multig,'ColumnEditable',true);



% --- Outputs from this function are returned to the command line.
function varargout = selectzforassociatedFSCs_multig_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when selected cell(s) is changed in selectzforassociatedFSCs_multig_gui.
function selectzforassociatedFSCs_multig_gui_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to selectzforassociatedFSCs_multig_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
effectrowIndex=[];
hang = eventdata.Indices(:,1);%��ȡ������
if isempty(hang)  
     return
end
if eventdata.Indices(2)==4%���ѡ����ǵ�����checkbox������в���
%                 event.Source.Data(event.Indices(1),event.Indices(2))
%                 �������data�н���һ�У����ã����������data�Ǿ���������ʹ��{}
      if eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2) }                
         eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)}=false;
      else
          eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)} =true;
      end
end
matrix = get(hObject,'Data') ;      %��ȡ���ݾ���
 selectIndex={1};           %��������б�ѡ��Ϊ1���ǲ�Ҫ���������
    rowIndex =[rowIndex,hang];          %��������ֵ
   for m=1:1:length(rowIndex)
        if isequal(matrix(rowIndex(m),4),selectIndex)
            effectrowIndex =[effectrowIndex,rowIndex(m)];%��������ֵ
        end
  end
  effectrowIndex=sort(unique(effectrowIndex));
   rowIndex=effectrowIndex;
handles.effectrowIndex = effectrowIndex;             %�����������ӵ��ṹ��
 guidata(hObject, handles); 


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Number_of_Critical_Pairs
close(selectzforassociatedFSCs_multig)


% --- Executes on button press in average_gui.
% function average_gui_Callback(hObject, eventdata, handles)
% % hObject    handle to average_gui (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% global rowIndex;
% rowIndex=[];
% effectrowIndex = handles.effectrowIndex;
% %load('matrix_wandzforassociatedFSCs_g1.mat');
% matrix_wandzandgforassociatedFSCs_multig = get(handles.selectzforassociatedFSCs_multig_gui,'Data');
% matrix_wandzandgforassociatedFSCs_multig=matrix_wandzandgforassociatedFSCs_multig(:,1:3);    %��ȡ�������ݾ���
% matrix_wandzandgforassociatedFSCs_multig=cell2mat(matrix_wandzandgforassociatedFSCs_multig);
% mergeData = matrix_wandzandgforassociatedFSCs_multig(effectrowIndex,:);
% %round(a*2)/2
% matrix_wandzandgforassociatedFSCs_multig(effectrowIndex(1),:) = mean(mergeData);
% for k=2:length(effectrowIndex)
%     matrix_wandzandgforassociatedFSCs_multig(effectrowIndex(k),:) = [];
% end
% matrix_wandzandgforassociatedFSCs_multig=[matrix_wandzandgforassociatedFSCs_multig,zeros(size(matrix_wandzandgforassociatedFSCs_multig,1),1)];
% matrix_wandzandgforassociatedFSCs_multig=num2cell(matrix_wandzandgforassociatedFSCs_multig);
% set(handles.selectzforassociatedFSCs_multig_gui,'Data',matrix_wandzandgforassociatedFSCs_multig); 
%  save('matrix_wandzandgforassociatedFSCs_multig.mat','matrix_wandzandgforassociatedFSCs_multig');  %����һ������


% --- Executes on button press in merge_gui.
function merge_gui_Callback(hObject, eventdata, handles)
% hObject    handle to merge_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
rowIndex=[];
effectrowIndex = handles.effectrowIndex;
%load('matrix_wandzforassociatedFSCs_g1.mat');
matrix_wandzandgforassociatedFSCs_multig = get(handles.selectzforassociatedFSCs_multig_gui,'Data');
matrix_wandzandgforassociatedFSCs_multig=matrix_wandzandgforassociatedFSCs_multig(:,1:3);    %��ȡ�������ݾ���
matrix_wandzandgforassociatedFSCs_multig=cell2mat(matrix_wandzandgforassociatedFSCs_multig);
targetData = matrix_wandzandgforassociatedFSCs_multig(effectrowIndex,:);
averageData=targetData(:,1:2);
mergeData=targetData(:,3);
%round(a*2)/2
matrix_wandzandgforassociatedFSCs_multig(effectrowIndex(1),1:2) = mean(averageData);
matrix_wandzandgforassociatedFSCs_multig(effectrowIndex(1),3)=sum(mergeData);
for k=2:length(effectrowIndex)
    matrix_wandzandgforassociatedFSCs_multig(effectrowIndex(k),:) = [];
end
matrix_wandzandgforassociatedFSCs_multig=[matrix_wandzandgforassociatedFSCs_multig,zeros(size(matrix_wandzandgforassociatedFSCs_multig,1),1)];
matrix_wandzandgforassociatedFSCs_multig=num2cell(matrix_wandzandgforassociatedFSCs_multig);
set(handles.selectzforassociatedFSCs_multig_gui,'Data',matrix_wandzandgforassociatedFSCs_multig); 
 save('matrix_wandzandgforassociatedFSCs_multig.mat','matrix_wandzandgforassociatedFSCs_multig');  %����һ������


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    load('matrix_wandzforassociatedsingleFSC_g1.mat');
    global rowIndex;
    rowIndex=[];
    effectrowIndex = handles.effectrowIndex;
    matrix_wandzandgforassociatedFSCs_multig=get(handles.selectzforassociatedFSCs_multig_gui,'Data');
    matrix_wandzforassociatedFSCs_multig=matrix_wandzandgforassociatedFSCs_multig(:,1:2);        %��ȡ�������ݾ���
    matrix_wandzandgforassociatedFSCs_multig=matrix_wandzandgforassociatedFSCs_multig(:,1:3);
    %����û���Ҫ��w��z��z�ľ���ֵ
     matrix_wandzandgforassociatedFSCs_multig= matrix_wandzandgforassociatedFSCs_multig(effectrowIndex,:);
     matrix_wandzandgforassociatedFSCs_multig=cell2mat(matrix_wandzandgforassociatedFSCs_multig);
     
    matrix_effectwandzforassociatedFSCs_multig = matrix_wandzforassociatedFSCs_multig(effectrowIndex,:);
    matrix_effectwandzforassociatedFSCs_multig=cell2mat(matrix_effectwandzforassociatedFSCs_multig);
    
    matrix_wandzforassociatedsingleFSC_multig=matrix_wandzforassociatedsingleFSC_g1;
    matrix_wandzforassociatedsingleFSC_multig=cell2mat(matrix_wandzforassociatedsingleFSC_multig);
    
    %�û�ѡ����������Ч��w��z��z�ľ���ֵ���������Ӧ��Ƶ��ɨ�����ߵ����Ͷ��������
    matrix_alleffectwandzforassociatedFSCs_multig=[matrix_effectwandzforassociatedFSCs_multig;matrix_wandzforassociatedsingleFSC_multig];
    matrix_alleffectwandzforassociatedFSCs_multig=num2cell(matrix_alleffectwandzforassociatedFSCs_multig);
    
    matrix_alleffectwandzandgforassociatedFSCs_multig=[matrix_wandzandgforassociatedFSCs_multig;[matrix_wandzforassociatedsingleFSC_multig,ones(size(matrix_wandzforassociatedsingleFSC_multig,1), 1)]];
    matrix_alleffectwandzandgforassociatedFSCs_multig=num2cell(matrix_alleffectwandzandgforassociatedFSCs_multig);
    save('matrix_alleffectwandzforassociatedFSCs_multig.mat','matrix_alleffectwandzforassociatedFSCs_multig');
    save('matrix_alleffectwandzandgforassociatedFSCs_multig.mat', 'matrix_alleffectwandzandgforassociatedFSCs_multig')
        close(selectzforassociatedFSCs_multig);
        alleffectwandzforassociatedFSCs_multig


% --- Executes when entered data in editable cell(s) in selectzforassociatedFSCs_multig_gui.
function selectzforassociatedFSCs_multig_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to selectzforassociatedFSCs_multig_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_wandzandgforassociatedFSCs_multig = get(hObject,'Data');
save('matrix_wandzandgforassociatedFSCs_multig.mat','matrix_wandzandgforassociatedFSCs_multig');
