function deltaNU=effectdeltaNUfor_multig 
global fzlambda;
global omega_max;
global numberofgridstoFSC;
global q;

load('matrix_alleffectwandzandgforassociatedFSCs_multig.mat')
 load('matrix_number_of_associated_FSCs.mat');
 load('matrix_number_of_critical_pairs.mat');
 
%   matrix_alleffectwandzandgforassociatedFSCs_multig=[1,-1,1;1,1,1;1.31607401295249,0.366025403784439 - 0.930604859102102i,1;1.31607401295249,0.366025403784439 + 0.930604859102102i,1]
%   matrix_number_of_associated_FSCs=[1,2;1.31607401295249,2]
%   matrix_number_of_critical_pairs=[1,2;1.31607401295249,2]
%     matrix_alleffectwandzandgforassociatedFSCs_multig=num2cell(  matrix_alleffectwandzandgforassociatedFSCs_multig)
%     matrix_number_of_associated_FSCs=num2cell(matrix_number_of_associated_FSCs)
%     matrix_number_of_critical_pairs=num2cell(matrix_number_of_critical_pairs)
    
matrix_alleffectwandzandgforassociatedFSCs_multig=cell2mat(matrix_alleffectwandzandgforassociatedFSCs_multig);
matrix_w=matrix_alleffectwandzandgforassociatedFSCs_multig(:,1);

matrix_number_of_critical_pairs=cell2mat(matrix_number_of_critical_pairs);
matrix_number_of_associated_FSCs=cell2mat(matrix_number_of_associated_FSCs);
%matrix_modForwandnumber_of_associated_FSCsandcritical_pairs�������ű任λ�ú��omega�����Ӧ��fsc������critical
%paris����
matrix_modForwandnumber_of_associated_FSCsandcritical_pairs=zeros(size(matrix_number_of_associated_FSCs,1),3);
for i=1:1:length(matrix_w)
    matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(i,1)=matrix_w(i);
    for p=1:1:size(matrix_number_of_associated_FSCs,1)
        if abs(matrix_w(i))==abs(matrix_number_of_associated_FSCs(p,1))
            matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(i,2)=matrix_number_of_associated_FSCs(p,2);
        end  
    end
     for r=1:1:size(matrix_number_of_critical_pairs,1)
        if abs(matrix_w(i))==abs(matrix_number_of_critical_pairs(r,1))
            matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(i,3)=matrix_number_of_critical_pairs(r,2);
        end  
    end
end

syms s;
   deltaNU = [];   
   for n=1:1:length(matrix_w)
    firstfsc=0;
    nextfsc=0; 
     numberofg=matrix_alleffectwandzandgforassociatedFSCs_multig(n,3);
    curretomega=matrix_w(n) ;
       %fzlambda_vector=(subs(fzlambda,s,curretomega*j));
       fzlambda_vectorleft=(subs(fzlambda,s,(curretomega-omega_max/numberofgridstoFSC)*j));
       fzlambda_vectorright=(subs(fzlambda,s,(curretomega+omega_max/numberofgridstoFSC)*j));
      % z=vpa(roots(fzlambda_vector));
       zleft=vpa(roots(fzlambda_vectorleft));
       zright=vpa(roots(fzlambda_vectorright));
       if numberofg==1
           
           effectz=matrix_alleffectwandzandgforassociatedFSCs_multig(n,2);
       end
       if numberofg ~= 1
           fzlambda_vector=(subs(fzlambda,s,curretomega*j));
           z=vpa(roots(fzlambda_vector));
            abs_z=abs(z);
       distence_z_to_1=abs(abs_z-1);
        [sortdistence_z_to_1 , index]=sort(distence_z_to_1);
        effectz=z(index(1:matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(n,2)));
       end
    %q=3;
%     zleft=[1.1; 2.1; 1.3];
%     zright=[2.3 ;1.15; 0.95];
%     effectz=[1; 2; 1.005];
    
   
   
    
    %�д�
  
        if (numberofg>matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(n,2))
            fprintf('����');
            return;
        end
    
    
    %g��number_of_associated_fscs��� 
    if  numberofg==1 
        %�Ҷ�Ӧ��һ��fsc�ϵ�ǰһ������ֵ�ͺ�һ������ֵ
            effectzleft_gnotequalsassociatedfscs=zeros(q,1);
            effectzright_gnotequalsassociatedfscs=zeros(q,1);
            nearzleft=zeros(q,1);
            nearzright=zeros(q,1);
            for zindex=1:1:length(effectz)
                for zleftindex = 1:1:length(zleft)
                    nearzleft(zleftindex,:)= abs(zleft(zleftindex)-effectz(zindex));
                end
                [sortnearzleft,indexnearzleft]=sort(nearzleft);
                effectzleft_gnotequalsassociatedfscs(zindex)=[zleft(indexnearzleft(1))];
            end       
           for zindex=1:1:length(effectz)
                for zrightindex = 1:1:length(zright)
                    nearzright(zrightindex,:)=abs(zright(zrightindex)-effectz(zindex));
                end
                [sortnearzright,indexnearzright]=sort(nearzright);
                effectzright_gnotequalsassociatedfscs(zindex)=[zright(indexnearzright(1))];
            end
        
       %���¼���g����1����µ�deltaNU

            for k=1:1:length(effectz)
                if abs(effectzleft_gnotequalsassociatedfscs(k)) > 1 && abs(effectzright_gnotequalsassociatedfscs(k)) > 1
                    deltaNU=[deltaNU,0];
                end
                if abs(effectzleft_gnotequalsassociatedfscs(k)) < 1 && abs(effectzright_gnotequalsassociatedfscs(k)) < 1
                    deltaNU=[deltaNU,0];
                end
                if abs(effectzleft_gnotequalsassociatedfscs(k)) > 1 && abs(effectzright_gnotequalsassociatedfscs(k)) < 1
                    deltaNU=[deltaNU,-1];
                end
                if abs(effectzleft_gnotequalsassociatedfscs(k)) < 1 && abs(effectzright_gnotequalsassociatedfscs(k)) > 1
                    deltaNU=[deltaNU,1];
                end
            end
    end     
            
    if numberofg~=1
        % %���¼���g������1���
              %��z�ֶ�
           effectzforg=find_min(effectz',numberofg);   %����м����߹���һ��g
          
           
           %��ǰ��һ��z��ǰ�󲽳���Чfsc
            nearzleft=zeros(q,1);
            nearzright=zeros(q,1);
            for zleftindex=1:1:length(zleft)
                for k = 1:1:length(effectzforg)
                    nearzleft(zleftindex,:)= nearzleft(zleftindex,:) + abs(zleft(zleftindex)-effectzforg(k));
                end
            end       
           for zrightindex=1:1:length(zright)
                for k = 1:1:length(effectzforg)
                    nearzright(zrightindex,:)= nearzright(zrightindex,:) + abs(zright(zrightindex)-effectzforg(k));
                end
            end
        [sortnearzleft,indexnearzleft]=sort(nearzleft);
        [sortnearzright,indexnearzright]=sort(nearzright);
        effectzleft=zleft(indexnearzleft(1:numberofg));
        effectzright=zright(indexnearzright(1:numberofg));
        %���¼���deltaNU
        for numzleft=1:1:length(effectzleft)
           if abs(effectzleft(numzleft)) > 1
               firstfsc = firstfsc + 1;
           end
           if abs(effectzleft(numzleft)) < 1
              firstfsc = firstfsc - 1;
           end
        end
        for numzright=1:1:length(effectzright)
           if abs(effectzright(numzright)) > 1
               nextfsc = nextfsc + 1;
           end
           if abs(effectzright(numzright)) < 1
              nextfsc = nextfsc - 1;
           end
        end
         deltaNU=[deltaNU,(nextfsc-firstfsc) / 2] ;
        
       end
    end
    
   
        
    
           

        