function varargout = NUepsilon_CDs_Periods(varargin)
% NUEPSILON_CDS_PERIODS MATLAB code for NUepsilon_CDs_Periods.fig
%      NUEPSILON_CDS_PERIODS, by itself, creates a new NUEPSILON_CDS_PERIODS or raises the existing
%      singleton*.
%
%      H = NUEPSILON_CDS_PERIODS returns the handle to a new NUEPSILON_CDS_PERIODS or the handle to
%      the existing singleton*.
%
%      NUEPSILON_CDS_PERIODS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NUEPSILON_CDS_PERIODS.M with the given input arguments.
%
%      NUEPSILON_CDS_PERIODS('Property','Value',...) creates a new NUEPSILON_CDS_PERIODS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before NUepsilon_CDs_Periods_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to NUepsilon_CDs_Periods_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help NUepsilon_CDs_Periods

% Last Modified by GUIDE v2.5 17-Feb-2021 21:18:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @NUepsilon_CDs_Periods_OpeningFcn, ...
                   'gui_OutputFcn',  @NUepsilon_CDs_Periods_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before NUepsilon_CDs_Periods is made visible.
function NUepsilon_CDs_Periods_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to NUepsilon_CDs_Periods (see VARARGIN)

% Choose default command line output for NUepsilon_CDs_Periods
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
matrix_wandCDsandZeros=[];
 load('newMatrixfor_wandz.mat');
 if ~isempty(newMatrixfor_wandz)
 newMatrixfor_wandz = cell2mat(newMatrixfor_wandz);
sumColumns= sum(newMatrixfor_wandz(:,2));
 matrix_w=zeros(1,sumColumns);
 m=1;
 for k=1:1:size(newMatrixfor_wandz,1)
     if newMatrixfor_wandz(k,2) == 1
         matrix_w(1,m)=newMatrixfor_wandz(k,1);
         m=m+1;
     end
     if newMatrixfor_wandz(k,2) ~= 1
         matrix_w(1,m:m+newMatrixfor_wandz(k,2)-1)=newMatrixfor_wandz(k,1);
         m=m+newMatrixfor_wandz(k,2);
     end
 end
%    matrix_w=w_and_DeltaMatrix(1,:)
     CDsandPeriods=CDSandPeriods;
      matrix_wandCDsandPeriodsforEpsilon=[matrix_w;CDsandPeriods];
      matrix_wandCDs=matrix_wandCDsandPeriodsforEpsilon(1:2,:);
      matrix_wandCDsandZeros=[matrix_wandCDs',zeros(size(matrix_wandCDs',1),1)];
      matrix_wandCDsandZeros=num2cell(matrix_wandCDsandZeros);
 end
     set(handles.CDsandPeriods_gui,'Data',matrix_wandCDsandZeros,'ColumnEditable',true);
     save('matrix_wandCDsandZeros.mat','matrix_wandCDsandZeros');
     save('matrix_wandCDsandPeriodsforEpsilon.mat','matrix_wandCDsandPeriodsforEpsilon');

% UIWAIT makes NUepsilon_CDs_Periods wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = NUepsilon_CDs_Periods_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when entered data in editable cell(s) in CDsandPeriods_gui.
function CDsandPeriods_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to CDsandPeriods_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_wandCDsandZeros = get(hObject,'Data');
save('matrix_wandCDsandZeros.mat','matrix_wandCDsandZeros');


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
global NUdelayEpsilon;
NumberOfNUEpsilon = get(handles.edit1,'String'); 
 NUdelayEpsilon=str2num(NumberOfNUEpsilon);
% --- Executes during object creation, after setting all properties.

function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
rowIndex=[];
effectrowIndex = handles.effectrowIndex;
load('matrix_wandCDsandPeriodsforEpsilon');
matrix_wandCDsandZeros=get(handles.CDsandPeriods_gui,'Data');
effectMatrix_wandCDsandZeros=matrix_wandCDsandZeros(:,[1,2]);
effectMatrix_wandCDsandZeros=cell2mat(effectMatrix_wandCDsandZeros);
effectMatrix_wandCDsandZeros(effectrowIndex,2)=matrix_wandCDsandPeriodsforEpsilon(3,effectrowIndex);
save('effectMatrix_wandCDsandZeros.mat','effectMatrix_wandCDsandZeros');
save('matrix_wandCDsandPeriodsforEpsilon.mat','matrix_wandCDsandPeriodsforEpsilon');
%close(NUepsilon_CDs_Periods)

%CDsandPeriodsforEpsilon=CDSandPeriodsforEpsilon;
  NUtauforEpsilon;


% --- Executes on button press in return_gui.
function return_gui_Callback(hObject, eventdata, handles)
% hObject    handle to return_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(NUepsilon_CDs_Periods)
lambdarootf0


% --- Executes when selected cell(s) is changed in CDsandPeriods_gui.
function CDsandPeriods_gui_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to CDsandPeriods_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)

global rowIndex;
effectrowIndex=[];
hang = eventdata.Indices(:,1);%��ȡ������
if isempty(hang)  
     return
end
if eventdata.Indices(2)==3%���ѡ����ǵ�����checkbox������в���
%                 event.Source.Data(event.Indices(1),event.Indices(2))
%                 �������data�н���һ�У����ã����������data�Ǿ���������ʹ��{}
      if eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2) }                
         eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)}=false;
      else
          eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)} =true;
      end
end
matrix = get(hObject,'Data');        %��ȡ���ݾ���
 selectIndex={1};           %��������б�ѡ��Ϊ1���ǲ�Ҫ���������
    rowIndex =[rowIndex,hang];          %��������ֵ
   for m=1:1:length(rowIndex)
        if isequal(matrix(rowIndex(m),3),selectIndex)
            effectrowIndex =[effectrowIndex,rowIndex(m)];%��������ֵ
        end
  end
  effectrowIndex=sort(unique(effectrowIndex));
   rowIndex=effectrowIndex;
handles.effectrowIndex = effectrowIndex;             %�����������ӵ��ṹ��
 guidata(hObject, handles); 
