function varargout = selectzforassociatedFSCs_g1(varargin)
% SELECTZFORASSOCIATEDFSCS_G1 MATLAB code for selectzforassociatedFSCs_g1.fig
%      SELECTZFORASSOCIATEDFSCS_G1, by itself, creates a new SELECTZFORASSOCIATEDFSCS_G1 or raises the existing
%      singleton*.
%
%      H = SELECTZFORASSOCIATEDFSCS_G1 returns the handle to a new SELECTZFORASSOCIATEDFSCS_G1 or the handle to
%      the existing singleton*.
%
%      SELECTZFORASSOCIATEDFSCS_G1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECTZFORASSOCIATEDFSCS_G1.M with the given input arguments.
%
%      SELECTZFORASSOCIATEDFSCS_G1('Property','Value',...) creates a new SELECTZFORASSOCIATEDFSCS_G1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before selectzforassociatedFSCs_g1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to selectzforassociatedFSCs_g1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help selectzforassociatedFSCs_g1

% Last Modified by GUIDE v2.5 24-Jun-2021 17:24:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @selectzforassociatedFSCs_g1_OpeningFcn, ...
                   'gui_OutputFcn',  @selectzforassociatedFSCs_g1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before selectzforassociatedFSCs_g1 is made visible.
function selectzforassociatedFSCs_g1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to selectzforassociatedFSCs_g1 (see VARARGIN)

% Choose default command line output for selectzforassociatedFSCs_g1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes selectzforassociatedFSCs_g1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);
global rowIndex;
rowIndex=[];
load('matrix_wandzforassociatedFSCs_g1.mat')
set(handles.selectzforassociatedFSCs_g1_gui,'Data',matrix_wandzforassociatedFSCs_g1,'ColumnEditable',true);

% --- Outputs from this function are returned to the command line.
function varargout = selectzforassociatedFSCs_g1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when selected cell(s) is changed in selectzforassociatedFSCs_g1_gui.
function selectzforassociatedFSCs_g1_gui_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to selectzforassociatedFSCs_g1_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
effectrowIndex=[];
hang = eventdata.Indices(:,1);%��ȡ������
if isempty(hang)  
     return
end
if eventdata.Indices(2)==3%���ѡ����ǵ�����checkbox������в���
%                 event.Source.Data(event.Indices(1),event.Indices(2))
%                 �������data�н���һ�У����ã����������data�Ǿ���������ʹ��{}
      if eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2) }                
         eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)}=false;
      else
          eventdata.Source.Data{eventdata.Indices(1),eventdata.Indices(2)} =true;
      end
end
matrix = get(hObject,'Data') ;      %��ȡ���ݾ���
 selectIndex={1};           %��������б�ѡ��Ϊ1���ǲ�Ҫ���������
    rowIndex =[rowIndex,hang];          %��������ֵ
   for m=1:1:length(rowIndex)
        if isequal(matrix(rowIndex(m),3),selectIndex)
            effectrowIndex =[effectrowIndex,rowIndex(m)];%��������ֵ
        end
  end
  effectrowIndex=sort(unique(effectrowIndex));
   rowIndex=effectrowIndex;
handles.effectrowIndex = effectrowIndex;             %�����������ӵ��ṹ��
 guidata(hObject, handles); 


% --- Executes when entered data in editable cell(s) in selectzforassociatedFSCs_g1_gui.
function selectzforassociatedFSCs_g1_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to selectzforassociatedFSCs_g1_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_wandzforassociatedFSCs_g1 = get(hObject,'Data');
save('matrix_wandzforassociatedFSCs_g1.mat','matrix_wandzforassociatedFSCs_g1');


% --- Executes on button press in merge_gui.
function merge_gui_Callback(hObject, eventdata, handles)
% hObject    handle to merge_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rowIndex;
rowIndex=[];
effectrowIndex = handles.effectrowIndex;
load('matrix_wandzforassociatedFSCs_g1.mat');
matrix_wandzforassociatedFSCs_g1 = get(handles.selectzforassociatedFSCs_g1_gui,'Data');
matrix_wandzforassociatedFSCs_g1=matrix_wandzforassociatedFSCs_g1(:,1:2);    %��ȡ�������ݾ���
matrix_wandzforassociatedFSCs_g1=cell2mat(matrix_wandzforassociatedFSCs_g1);
mergeData = matrix_wandzforassociatedFSCs_g1(effectrowIndex,:);
%round(a*2)/2
matrix_wandzforassociatedFSCs_g1(effectrowIndex(1),:) = mean(mergeData);
for k=2:length(effectrowIndex)
    matrix_wandzforassociatedFSCs_g1(effectrowIndex(k),:) = [];
end
matrix_wandzforassociatedFSCs_g1=[matrix_wandzforassociatedFSCs_g1,zeros(size(matrix_wandzforassociatedFSCs_g1,1),1)];
matrix_wandzforassociatedFSCs_g1=num2cell(matrix_wandzforassociatedFSCs_g1);
set(handles.selectzforassociatedFSCs_g1_gui,'Data',matrix_wandzforassociatedFSCs_g1); 
 save('matrix_wandzforassociatedFSCs_g1.mat','matrix_wandzforassociatedFSCs_g1');  %����һ������


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Number_of_Critical_Pairs
close(selectzforassociatedFSCs_g1)


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load('matrix_wandzforassociatedsingleFSC_g1.mat');
    global rowIndex;
    rowIndex=[];
    effectrowIndex = handles.effectrowIndex;
    matrix_wandzforassociatedFSCs_g1 = get(handles.selectzforassociatedFSCs_g1_gui,'Data'); 
    matrix_wandzforassociatedFSCs_g1=matrix_wandzforassociatedFSCs_g1(:,1:2);        %��ȡ�������ݾ���
    
    %����û���Ҫ��w��z��z�ľ���ֵ
    matrix_effectwandzforassociatedFSCs_g1 = matrix_wandzforassociatedFSCs_g1(effectrowIndex,:);
    matrix_effectwandzforassociatedFSCs_g1=cell2mat(matrix_effectwandzforassociatedFSCs_g1);
    matrix_wandzforassociatedsingleFSC_g1=cell2mat(matrix_wandzforassociatedsingleFSC_g1);
    
    %�û�ѡ����������Ч��w��z��z�ľ���ֵ���������Ӧ��Ƶ��ɨ�����ߵ����Ͷ��������
    matrix_alleffectwandzforassociatedFSCs_g1=[matrix_effectwandzforassociatedFSCs_g1;matrix_wandzforassociatedsingleFSC_g1];
    matrix_alleffectwandzforassociatedFSCs_g1=num2cell(matrix_alleffectwandzforassociatedFSCs_g1);
    save('matrix_alleffectwandzforassociatedFSCs_g1.mat','matrix_alleffectwandzforassociatedFSCs_g1');
        close(selectzforassociatedFSCs_g1);
        alleffectwandzforassociatedFSCs_g1
