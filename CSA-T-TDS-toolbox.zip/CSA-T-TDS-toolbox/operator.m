function varargout = operator(varargin)
% OPERATOR MATLAB code for operator.fig
%      OPERATOR, by itself, creates a new OPERATOR or raises the existing
%      singleton*.
%
%      H = OPERATOR returns the handle to a new OPERATOR or the handle to
%      the existing singleton*.
%
%      OPERATOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OPERATOR.M with the given input arguments.
%
%      OPERATOR('Property','Value',...) creates a new OPERATOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before operator_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to operator_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help operator

% Last Modified by GUIDE v2.5 18-Mar-2021 17:30:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @operator_OpeningFcn, ...
                   'gui_OutputFcn',  @operator_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before operator is made visible.
function operator_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to operator (see VARARGIN)

% Choose default command line output for operator
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes operator wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = operator_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in yes1_gui.
function yes1_gui_Callback(hObject, eventdata, handles)
% hObject    handle to yes1_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of yes1_gui


% --- Executes on button press in no1_gui.
function no1_gui_Callback(hObject, eventdata, handles)
% hObject    handle to no1_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% Hint: get(hObject,'Value') returns toggle state of no1_gui


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fzlambda;
syms s w;
if get(handles.yes1_gui,'Value') == 1 
     flambda=subs(fzlambda,s,j*w);
       [matrix,matrixOriginal]=auxiliaryequation(flambda) ;  
        NUdelay0;
        W_Roots;
   close(operator);
else
if get(handles.no1_gui,'Value') == 1
    disp('The system doesn''t have a stable interval.');
     close(operator);
end
end

% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
settings;
global h;
close(h)
close(operator)
