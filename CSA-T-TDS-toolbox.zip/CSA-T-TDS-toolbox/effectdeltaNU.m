function deltaNU=effectdeltaNU
deltaNU=[];
global fzlambda;
global omega_max;
global numberofgridstoFSC;
syms s z;
load('newMatrix.mat');
newMatrix=cell2mat(newMatrix);
newMatrix_w=newMatrix(:,1);
for m=1:1:length(newMatrix_w)
     curretomega=newMatrix_w(m) ;
       fzlambda_value1(m,:)=(subs(fzlambda,s,(curretomega-omega_max/numberofgridstoFSC)*j));
       fzlambda_value2(m,:)=(subs(fzlambda,s,(curretomega+omega_max/numberofgridstoFSC)*j));
       z1(m,:)=vpa(roots(fzlambda_value1(m,:)));
       z2(m,:)=vpa(roots(fzlambda_value2(m,:)));
        abs_z1(m,:)=abs(z1(m,:));
        abs_z2(m,:)=abs(z2(m,:));
          distence_z_to_1_1(m,:)=abs(abs_z1(m,:)-1);
          distence_z_to_1_2(m,:)=abs(abs_z2(m,:)-1);
       [sortdistence_z_to_1_1(m,:) index1(m,:)]=sort(distence_z_to_1_1(m,:));
        [sortdistence_z_to_1_2(m,:) index2(m,:)]=sort(distence_z_to_1_2(m,:));
        effectz1(m,:)=z1(m,index1(m,1));
        effectz2(m,:)=z2(m,index2(m,1));
        
end
for k=1:1:length(effectz1)
     abseffectz2=abs(effectz2(k));
          abseffectz1=abs(effectz1(k));
      if abseffectz2>1&&abseffectz1<1 
       deltaNU=[deltaNU,+1];
      end
      if abseffectz2<1&&abseffectz1>1
          
       deltaNU=[deltaNU,-1];
      end
      if abseffectz2>1&&abseffectz1>1  
       deltaNU=[deltaNU,0]; 
      end 
      if abseffectz2<1&&abseffectz1<1
          
       deltaNU=[deltaNU,0]; 
      end
end