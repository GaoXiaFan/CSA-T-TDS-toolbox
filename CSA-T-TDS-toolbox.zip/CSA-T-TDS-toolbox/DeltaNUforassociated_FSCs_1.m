function varargout = DeltaNUforassociated_FSCs_1(varargin)
% DELTANUFORASSOCIATED_FSCS_1 MATLAB code for DeltaNUforassociated_FSCs_1.fig
%      DELTANUFORASSOCIATED_FSCS_1, by itself, creates a new DELTANUFORASSOCIATED_FSCS_1 or raises the existing
%      singleton*.
%
%      H = DELTANUFORASSOCIATED_FSCS_1 returns the handle to a new DELTANUFORASSOCIATED_FSCS_1 or the handle to
%      the existing singleton*.
%
%      DELTANUFORASSOCIATED_FSCS_1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DELTANUFORASSOCIATED_FSCS_1.M with the given input arguments.
%
%      DELTANUFORASSOCIATED_FSCS_1('Property','Value',...) creates a new DELTANUFORASSOCIATED_FSCS_1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DeltaNUforassociated_FSCs_1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DeltaNUforassociated_FSCs_1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DeltaNUforassociated_FSCs_1

% Last Modified by GUIDE v2.5 20-Apr-2021 14:56:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DeltaNUforassociated_FSCs_1_OpeningFcn, ...
                   'gui_OutputFcn',  @DeltaNUforassociated_FSCs_1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DeltaNUforassociated_FSCs_1 is made visible.
function DeltaNUforassociated_FSCs_1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DeltaNUforassociated_FSCs_1 (see VARARGIN)

% Choose default command line output for DeltaNUforassociated_FSCs_1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DeltaNUforassociated_FSCs_1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);
load('matrix_wanddeltaNUforassociatedFSCs.mat');
set(handles.w_deltaNU_gui,'Data',matrix_wanddeltaNUforassociatedFSCs,'ColumnEditable',true);
save('matrix_wanddeltaNUforassociatedFSCs.mat','matrix_wanddeltaNUforassociatedFSCs'); %�����������Ա��棬�����´�ʹ��


% --- Outputs from this function are returned to the command line.
function varargout = DeltaNUforassociated_FSCs_1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(DeltaNUforassociated_FSCs_1)
alleffectwandzforassociatedFSCs

% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lambdarootf0
close(DeltaNUforassociated_FSCs_1)

% --- Executes when entered data in editable cell(s) in w_deltaNU_gui.
function w_deltaNU_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to w_deltaNU_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)

matrix_wanddeltaNUforassociatedFSCs = get(hObject,'Data');
w_and_DeltaMatrix=matrix_wanddeltaNUforassociatedFSCs;
save('matrix_wanddeltaNUforassociatedFSCs.mat','matrix_wanddeltaNUforassociatedFSCs');
save('w_and_DeltaMatrix.mat','w_and_DeltaMatrix');
