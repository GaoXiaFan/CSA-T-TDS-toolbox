function varargout = number_of_associated_FSCs(varargin)
% NUMBER_OF_ASSOCIATED_FSCS MATLAB code for number_of_associated_FSCs.fig
%      NUMBER_OF_ASSOCIATED_FSCS, by itself, creates a new NUMBER_OF_ASSOCIATED_FSCS or raises the existing
%      singleton*.
%
%      H = NUMBER_OF_ASSOCIATED_FSCS returns the handle to a new NUMBER_OF_ASSOCIATED_FSCS or the handle to
%      the existing singleton*.
%
%      NUMBER_OF_ASSOCIATED_FSCS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NUMBER_OF_ASSOCIATED_FSCS.M with the given input arguments.
%
%      NUMBER_OF_ASSOCIATED_FSCS('Property','Value',...) creates a new NUMBER_OF_ASSOCIATED_FSCS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before number_of_associated_FSCs_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to number_of_associated_FSCs_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help number_of_associated_FSCs

% Last Modified by GUIDE v2.5 20-Apr-2021 14:27:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @number_of_associated_FSCs_OpeningFcn, ...
                   'gui_OutputFcn',  @number_of_associated_FSCs_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before number_of_associated_FSCs is made visible.
function number_of_associated_FSCs_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to number_of_associated_FSCs (see VARARGIN)

% Choose default command line output for number_of_associated_FSCs
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
load('newMatrix.mat');
if ~isempty(newMatrix)
  set(handles.number_of_associated_FSCs_gui,'Data',newMatrix,'ColumnEditable',true); 
end
save('newMatrix.mat','newMatrix'); 

% UIWAIT makes number_of_associated_FSCs wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = number_of_associated_FSCs_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(number_of_associated_FSCs)
W_Roots


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fzlambda;
flag=0;
matrix_number_of_associated_FSCs=get(handles.number_of_associated_FSCs_gui,'Data');
matrix_FSCs=matrix_number_of_associated_FSCs(:,2);
matrix_FSCs=cell2mat(matrix_FSCs);
for k=1:1:length(matrix_FSCs)
    if matrix_FSCs(k) ~= 1
        flag=flag+1;
        break;
    end
end
if flag == 0
    deltaNU=effectdeltaNU;
       load('newMatrix.mat');
        newMatrixfor_wandz=newMatrix;%�����������CDsandPeriods�ļ��к�NUepsilon_CDs_Periods
        %w_and_FSCsMatrix=newMatrix;
        matrix_number_of_associated_FSCs=cell2mat(matrix_number_of_associated_FSCs);
        wMatrix=matrix_number_of_associated_FSCs(:,1);
        syms s;
        for n=1:1:length(wMatrix)
            omega_vector(n)=wMatrix(n);
        end
for k=1:1:length(omega_vector)
      curretomega=omega_vector(k) ;
      fzlambda_value(k,:)=subs(fzlambda,s,curretomega*j) ;
      z(k,:)=vpa(roots(fzlambda_value(k,:)));
          abs_z(k,:)=abs(z(k,:));
             distence_z_to_1(k,:)=abs(abs_z(k,:)-1);
          
       [sortdistence_z_to_1(k,:) index1(k,:)]=sort(distence_z_to_1(k,:));
        
        effectz(k,:)=z(k,index1(k,1));
        
end
        w_and_DeltaMatrix=[wMatrix,deltaNU'];   
        matrix_alleffectwandzforassociatedFSCs=num2cell([double(wMatrix),double(effectz)]);
    save('matrix_alleffectwandzforassociatedFSCs.mat', 'matrix_alleffectwandzforassociatedFSCs');
    save('w_and_DeltaMatrix.mat','w_and_DeltaMatrix');
    save('newMatrixfor_wandz.mat','newMatrixfor_wandz');
    save('matrix_number_of_associated_FSCs.mat','matrix_number_of_associated_FSCs');
    %DeltaNUforassociated_FSCs_1
    alleffectwandzforassociatedFSCs
    close(number_of_associated_FSCs)
end
if flag ~= 0
    
    matrix_number_of_critical_pairs=matrix_number_of_associated_FSCs;
    matrix_number_of_critical_pairs=cell2mat(matrix_number_of_critical_pairs);
    matrix_number_of_critical_pairs(:,2)=1;
    matrix_number_of_critical_pairs=num2cell(matrix_number_of_critical_pairs);
   save('matrix_number_of_critical_pairs.mat','matrix_number_of_critical_pairs');
    Number_of_Critical_Pairs
    close(number_of_associated_FSCs)
    
end
    


% --- Executes when entered data in editable cell(s) in number_of_associated_FSCs_gui.
function number_of_associated_FSCs_gui_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to number_of_associated_FSCs_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
matrix_number_of_associated_FSCs = get(hObject,'Data');
save('matrix_number_of_associated_FSCs.mat','matrix_number_of_associated_FSCs');
