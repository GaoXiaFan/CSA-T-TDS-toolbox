function CDsandPeriods=CDSandPeriods_g1
load('matrix_alleffectwandzforassociatedFSCs_g1.mat')
matrix_alleffectwandzforassociatedFSCs_g1=cell2mat(matrix_alleffectwandzforassociatedFSCs_g1);
CDsandPeriods=[];

    for t=1:1:size(matrix_alleffectwandzforassociatedFSCs_g1,1)
         criticalw=matrix_alleffectwandzforassociatedFSCs_g1(t,1);
        criticalZ=matrix_alleffectwandzforassociatedFSCs_g1(t,2);
        angZ=angle(criticalZ);
                        if angZ<=0
                            tau0=-1*angZ/criticalw;
                            period=2*pi/criticalw;
                        end
                        if angZ>0
                            tau0=(2*pi-angZ)/criticalw; 
                            period=2*pi/criticalw;
                        end
        CDsandPeriods=[CDsandPeriods,[tau0;period]];
    end


        