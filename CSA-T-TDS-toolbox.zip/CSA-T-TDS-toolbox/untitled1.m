   function deltaNU=effectdeltaNUfor_multig 
   global fzlambda;
global omega_max;
global numberofgridstoFSC;
global q;
load('matrix_alleffectwandzandgforassociatedFSCs_multig.mat')
matrix_alleffectwandzandgforassociatedFSCs_multig=cell2mat(matrix_alleffectwandzandgforassociatedFSCs_multig)
% load('matrix_number_of_associated_FSCs.mat');
% load('matrix_alleffectwandzforassociatedFSCs_multig.mat');
% load('matrix_number_of_critical_pairs.mat');
% load('matrix_wandzandgforassociatedFSCs_multig.mat');
% matrix_wandzandgforassociatedFSCs_multig=cell2mat(matrix_wandzandgforassociatedFSCs_multig)
% matrix_w=matrix_alleffectwandzforassociatedFSCs_multig(:,1);
% matrix_w=cell2mat(matrix_w);
% matrix_alleffectwandzforassociatedFSCs_multig=cell2mat(matrix_alleffectwandzforassociatedFSCs_multig);
% matrix_number_of_critical_pairs=cell2mat(matrix_number_of_critical_pairs)
%matrix_wAndNumberOfCriticalPairs=cell2mat(matrix_wAndNumberOfCriticalPairs);
matrix_number_of_associated_FSCs=cell2mat(matrix_number_of_associated_FSCs);
%matrix_modForwandnumber_of_associated_FSCsandcritical_pairs�������ű任λ�ú��omega�����Ӧ��fsc������critical
%paris����
matrix_modForwandnumber_of_associated_FSCsandcritical_pairs=zeros(size(matrix_number_of_associated_FSCs,1),3);
% for i=1:1:length(matrix_w)
%     matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(i,1)=matrix_w(i);
%     for p=1:1:size(matrix_number_of_associated_FSCs,1)
%         if matrix_w(i)==matrix_number_of_associated_FSCs(p,1)
%             matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(i,2)=matrix_number_of_associated_FSCs(p,2);
%         end  
%     end
%      for r=1:1:size(matrix_number_of_critical_pairs,1)
%         if matrix_w(i)==matrix_number_of_critical_pairs(r,1)
%             matrix_modForwandnumber_of_associated_FSCsandcritical_pairs(i,3)=matrix_number_of_critical_pairs(r,2);
%         end  
%     end
% end
matrix_w=matrix_alleffectwandzandgforassociatedFSCs_multig(:,1)
syms s;
   deltaNU = [];   
   for n=1:1:length(matrix_w)
    firstfsc=0;
    nextfsc=0; 
    curretomega=matrix_w(n) ;
       %fzlambda_vector=(subs(fzlambda,s,curretomega*j));
       fzlambda_vectorleft=(subs(fzlambda,s,(curretomega-omega_max/numberofgridstoFSC)*j));
       fzlambda_vectorright=(subs(fzlambda,s,(curretomega+omega_max/numberofgridstoFSC)*j));
      % z=vpa(roots(fzlambda_vector));
       zleft=vpa(roots(fzlambda_vectorleft));
       zright=vpa(roots(fzlambda_vectorright));
      effectz=matrix_alleffectwandzandgforassociatedFSCs_multig(n,2)
    %q=3;
%     zleft=[1.1; 2.1; 1.3];
%     zright=[2.3 ;1.15; 0.95];
%     effectz=[1; 2; 1.005];
    number_of_associated_fscs=3;
    numberg=2;
    number_of_gforfscvector=[1,2];
    
    %�д�
    for m=1:1:length(number_of_gforfscvector)
        if (number_of_gforfscvector(m)>number_of_associated_fscs)
            fprintf('����');
            return;
        end
    end
    
    %g��number_of_associated_fscs��� 
    if  number_of_associated_fscs==numberg  
        %�Ҷ�Ӧ��һ��fsc�ϵ�ǰһ������ֵ�ͺ�һ������ֵ
            effectzleft_gnotequalsassociatedfscs=zeros(q,1);
            effectzright_gnotequalsassociatedfscs=zeros(q,1);
            nearzleft=zeros(q,1);
            nearzright=zeros(q,1);
            for zindex=1:1:length(effectz)
                for zleftindex = 1:1:length(zleft)
                    nearzleft(zleftindex,:)= abs(zleft(zleftindex)-effectz(zindex));
                end
                [sortnearzleft,indexnearzleft]=sort(nearzleft);
                effectzleft_gnotequalsassociatedfscs(zindex)=[zleft(indexnearzleft(1))]
            end       
           for zindex=1:1:length(effectz)
                for zrightindex = 1:1:length(zright)
                    nearzright(zrightindex,:)=abs(zright(zrightindex)-effectz(zindex));
                end
                [sortnearzright,indexnearzright]=sort(nearzright);
                effectzright_gnotequalsassociatedfscs(zindex)=[zright(indexnearzright(1))]
            end
        
       %���¼���g��number_of_associated_fscs�������µ�deltaNU

            for k=1:1:length(effectz)
                if abs(effectzleft_gnotequalsassociatedfscs(k)) > 1 && abs(effectzright_gnotequalsassociatedfscs(k)) > 1
                    deltaNU=[deltaNU,0]
                end
                if abs(effectzleft_gnotequalsassociatedfscs(k)) < 1 && abs(effectzright_gnotequalsassociatedfscs(k)) < 1
                    deltaNU=[deltaNU,0]
                end
                if abs(effectzleft_gnotequalsassociatedfscs(k)) > 1 && abs(effectzright_gnotequalsassociatedfscs(k)) < 1
                    deltaNU=[deltaNU,-1]
                end
                if abs(effectzleft_gnotequalsassociatedfscs(k)) < 1 && abs(effectzright_gnotequalsassociatedfscs(k)) > 1
                    deltaNU=[deltaNU,1]
                end
            end
            
            
    else
        % %���¼���g��number_of_associated_fscs��������

        diffeffectz=[];
       for gindex=1:1:length(number_of_gforfscvector)
           number_of_g=number_of_gforfscvector(gindex)
           %���g=1�������жϣ���������ѭ��
           if number_of_g==1
              deltaNU = [deltaNU ,NaN]
              continue;
           end
           
%            for zindex=1:1:length(effectz)
%                znextindex=zindex + 1;
%                while znextindex<=length(effectz)
%                    effectz(zindex)
%                    effectz(znextindex)
%                    
%                    diffeffectz=[diffeffectz,abs(effectz(znextindex) - effectz(zindex))] 
%                    znextindex=znextindex+1
%                end
%              
%            end
%            [sortdiffeffectz, indexdiffeffectz]=sort(diffeffectz)
%            number_of_g

              %��z�ֶ�
           effectzforg=find_min(effectz',number_of_g);   %����м����߹���һ��g
          
           
           %��ǰ��һ��z��ǰ�󲽳���Чfsc
            nearzleft=zeros(q,1);
            nearzright=zeros(q,1);
            for zleftindex=1:1:length(zleft)
                for k = 1:1:length(effectzforg)
                    nearzleft(zleftindex,:)= nearzleft(zleftindex,:) + abs(zleft(zleftindex)-effectzforg(k))
                end
            end       
           for zrightindex=1:1:length(zright)
                for k = 1:1:length(effectzforg)
                    nearzright(zrightindex,:)= nearzright(zrightindex,:) + abs(zright(zrightindex)-effectzforg(k));
                end
            end
        [sortnearzleft,indexnearzleft]=sort(nearzleft);
        [sortnearzright,indexnearzright]=sort(nearzright);
        effectzleft=zleft(indexnearzleft(1:number_of_g))
        effectzright=zright(indexnearzright(1:number_of_g))
        %���¼���deltaNU
        for numzleft=1:1:length(effectzleft)
           if abs(effectzleft(numzleft)) > 1
               firstfsc = firstfsc + 1;
           end
           if abs(effectzleft(numzleft)) < 1
              firstfsc = firstfsc - 1;
           end
        end
        for numzright=1:1:length(effectzright)
           if abs(effectzright(numzright)) > 1
               nextfsc = nextfsc + 1;
           end
           if abs(effectzright(numzright)) < 1
              nextfsc = nextfsc - 1;
           end
        end
         deltaNU=[deltaNU,(nextfsc-firstfsc) / 2] 
         effectz=setdiff(effectz,effectzforg)
         zleft=setdiff(zleft,effectzleft)
         zright=setdiff(zright,effectzright)
       end
    end
    
    %��g=1��deltaNU���¼���
    for indexzforg1=1:1:length(effectz)
                effectzleft_gnotequalsassociatedfscs=zeros(length(effectz),1);
                effectzright_gnotequalsassociatedfscs=zeros(length(effectz),1);
                nearzleft=zeros(length(effectz),1);
                nearzright=zeros(length(effectz),1);
                for zindex=1:1:length(effectz)
                    for zleftindex = 1:1:length(zleft)
                        nearzleft(zleftindex,:)= abs(zleft(zleftindex)-effectz(zindex));
                    end
                    [sortnearzleft,indexnearzleft]=sort(nearzleft);
                    effectzleft_gnotequalsassociatedfscs(zindex)=[zleft(indexnearzleft(1))];
                end       
               for zindex=1:1:length(effectz)
                    for zrightindex = 1:1:length(zright)
                        nearzright(zrightindex,:)=abs(zright(zrightindex)-effectz(zindex));
                    end
                    [sortnearzright,indexnearzright]=sort(nearzright);
                    effectzright_gnotequalsassociatedfscs(zindex)=[zright(indexnearzright(1))];
               end
           %���¼���g��number_of_associated_fscs�������µ�deltaNU

                for k=1:1:length(effectz)
                    if abs(effectzleft_gnotequalsassociatedfscs(k)) > 1 && abs(effectzright_gnotequalsassociatedfscs(k)) > 1
                        for indexdeltaNU=1:1:length(deltaNU)
                            if isnan(deltaNU(indexdeltaNU))
                                deltaNU(indexdeltaNU)=0
                            end
                        end
                    end
                    if abs(effectzleft_gnotequalsassociatedfscs(k)) < 1 && abs(effectzright_gnotequalsassociatedfscs(k)) < 1
                       for indexdeltaNU=1:1:length(deltaNU)
                            if isnan(deltaNU(indexdeltaNU))
                                deltaNU(indexdeltaNU)=0
                            end
                        end
                    end
                    if abs(effectzleft_gnotequalsassociatedfscs(k)) > 1 && abs(effectzright_gnotequalsassociatedfscs(k)) < 1
                        for indexdeltaNU=1:1:length(deltaNU)
                            if isnan(deltaNU(indexdeltaNU))
                                deltaNU(indexdeltaNU)=-1
                            end
                        end
                    end
                    if abs(effectzleft_gnotequalsassociatedfscs(k)) < 1 && abs(effectzright_gnotequalsassociatedfscs(k)) > 1
                       for indexdeltaNU=1:1:length(deltaNU)
                            if isnan(deltaNU(indexdeltaNU))
                                deltaNU(indexdeltaNU)=1
                            end
                        end
                    end
                end
    end
           

    function varargout = alleffectwandzforassociatedFSCs_multig(varargin)
% ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG MATLAB code for alleffectwandzforassociatedFSCs_multig.fig
%      ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG, by itself, creates a new ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG or raises the existing
%      singleton*.
%
%      H = ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG returns the handle to a new ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG or the handle to
%      the existing singleton*.
%
%      ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG.M with the given input arguments.
%
%      ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG('Property','Value',...) creates a new ALLEFFECTWANDZFORASSOCIATEDFSCS_MULTIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before alleffectwandzforassociatedFSCs_multig_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to alleffectwandzforassociatedFSCs_multig_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help alleffectwandzforassociatedFSCs_multig

% Last Modified by GUIDE v2.5 14-Jun-2021 13:32:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @alleffectwandzforassociatedFSCs_multig_OpeningFcn, ...
                   'gui_OutputFcn',  @alleffectwandzforassociatedFSCs_multig_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before alleffectwandzforassociatedFSCs_multig is made visible.
function alleffectwandzforassociatedFSCs_multig_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to alleffectwandzforassociatedFSCs_multig (see VARARGIN)

% Choose default command line output for alleffectwandzforassociatedFSCs_multig
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes alleffectwandzforassociatedFSCs_multig wait for user response (see UIRESUME)
% uiwait(handles.figure1);
load('matrix_alleffectwandzforassociatedFSCs_multig.mat');
set(handles.alleffectwandzforassociatedFSCs_multig_gui,'Data',matrix_alleffectwandzforassociatedFSCs_multig,'ColumnEditable',true);


% --- Outputs from this function are returned to the command line.
function varargout = alleffectwandzforassociatedFSCs_multig_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in previous_gui.
function previous_gui_Callback(hObject, eventdata, handles)
% hObject    handle to previous_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(alleffectwandzforassociatedFSCs_multig)
selectzforassociatedFSCs_multig

% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%load('matrix_alleffectwandzforassociatedFSCs_multig.mat')
matrix_alleffectwandzforassociatedFSCs_multig=get(hObject,'Data');
matrix_alleffectw=matrix_alleffectwandzforassociatedFSCs_multig(:,1);
matrix_alleffectw=cell2mat(matrix_alleffectw);
deltaNU=effectdeltaNUfor_multig ;
matrix_wanddeltaNUforassociatedFSCs_multig=[matrix_alleffectw,deltaNU'];
save('matrix_wanddeltaNUforassociatedFSCs_multig.mat','matrix_wanddeltaNUforassociatedFSCs_multig')
DeltaNUforassociated_FSCs_multig
close(alleffectwandzforassociatedFSCs_multig)


function alleffectwandzforassociatedFSCs_multig_gui_CellEditCallback(hObject, eventdata, handles)
matrix_alleffectwandzforassociatedFSCs_multig = get(hObject,'Data');
save('matrix_alleffectwandzforassociatedFSCs_multig.mat','matrix_alleffectwandzforassociatedFSCs_multig');


% --- Executes when selected cell(s) is changed in alleffectwandzforassociatedFSCs_multig_gui.
function alleffectwandzforassociatedFSCs_multig_gui_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to alleffectwandzforassociatedFSCs_multig_gui (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)

        