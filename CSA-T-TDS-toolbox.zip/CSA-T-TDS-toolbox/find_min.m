function [return_min]=find_min(input_m,number_m)

  size_input=size(input_m,2);
   [a b]=sort(input_m);
   min_sort=[];
   for i=1:size_input-number_m+1
    sort_min=abs(a(number_m+i-1)-a(i))   ;
     min_sort=[min_sort sort_min];
       
   end
  position=find( min_sort==min(min_sort));
  return_min=input_m(b(position:position+number_m-1));
end
   
   





