function varargout = settingsfor_toolbox(varargin)
% settingsfor_toolbox MATLAB code for settingsfor_toolbox.fig
%      SETTINGSFOR_TOOLBOX, by itself, creates a new SETTINGSFOR_TOOLBOX or raises the existing
%      singleton*.
%
%      H = SETTINGSFOR_TOOLBOX returns the handle to a new SETTINGSFOR_TOOLBOX or the handle to
%      the existing singleton*.
%
%      SETTINGSFOR_TOOLBOX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SETTINGSFOR_TOOLBOX.M with the given input arguments.
%
%      SETTINGSFOR_TOOLBOX('Property','Value',...) creates a new SETTINGSFOR_TOOLBOX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before settingsfor_toolbox_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to settingsfor_toolbox_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help settingsfor_toolbox

% Last Modified by GUIDE v2.5 15-Jun-2021 10:20:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @settingsfor_toolbox_OpeningFcn, ...
                   'gui_OutputFcn',  @settingsfor_toolbox_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before settingsfor_toolbox is made visible.
function settingsfor_toolbox_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to settingsfor_toolbox (see VARARGIN)

% Choose default command line output for settingsfor_toolbox
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes settingsfor_toolbox wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = settingsfor_toolbox_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function tau_max_gui_Callback(hObject, eventdata, handles)
% hObject    handle to tau_max_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tau_max_gui as text
%        str2double(get(hObject,'String')) returns contents of tau_max_gui as a double


% --- Executes during object creation, after setting all properties.
function tau_max_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tau_max_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function omega_max_gui_Callback(hObject, eventdata, handles)
% hObject    handle to omega_max_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of omega_max_gui as text
%        str2double(get(hObject,'String')) returns contents of omega_max_gui as a double


% --- Executes during object creation, after setting all properties.
function omega_max_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to omega_max_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function numberofgridstoFSC_gui_Callback(hObject, eventdata, handles)
% hObject    handle to numberofgridstoFSC_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of numberofgridstoFSC_gui as text
%        str2double(get(hObject,'String')) returns contents of numberofgridstoFSC_gui as a double


% --- Executes during object creation, after setting all properties.
function numberofgridstoFSC_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numberofgridstoFSC_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in next_gui.
function next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global tau_max;
global omega_max;
global numberofgridstoFSC;
global numberofgridstoNUtau;
global fzlambda;
tau_max=str2num(get(handles.tau_max_gui,'String'));
omega_max=str2num(get(handles.omega_max_gui,'String'));
numberofgridstoFSC=str2num(get(handles.numberofgridstoFSC_gui,'String'));
numberofgridstoNUtau=str2num(get(handles.numberofgridstoNUtau_gui,'String'));

if isempty(tau_max) || isempty(omega_max) || isempty(numberofgridstoFSC) || isempty(numberofgridstoNUtau) 
     fprintf(2,'Please fill all the edit boxes.\n');
    return;
end

load coeMatrix
load smatrix
    fzlambda=smatrix*coeMatrix'; %����ʽ
    fzlambda=fliplr(fzlambda);

    %% ��Ƶ��ɨ��ͼ
    frequencycurve(numberofgridstoFSC,omega_max);
    close(settingsfor_toolbox);
   

function numberofgridstoNUtau_gui_Callback(hObject, eventdata, handles)
% hObject    handle to numberofgridstoNUtau_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of numberofgridstoNUtau_gui as text
%        str2double(get(hObject,'String')) returns contents of numberofgridstoNUtau_gui as a double


% --- Executes during object creation, after setting all properties.
function numberofgridstoNUtau_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to numberofgridstoNUtau_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
